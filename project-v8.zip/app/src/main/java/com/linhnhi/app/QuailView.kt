package com.linhnhi.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class QuailView(ctx: Context) : View(ctx) {

    enum class Mode { IDLE, LISTENING, THINKING, SPEAKING }

    @Volatile var mode = Mode.IDLE
    @Volatile var level = 0f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val path = Path()
    private val rect = RectF()

    private val cHead = Color.parseColor("#D9A066")
    private val cSpot = Color.parseColor("#B57A44")
    private val cCream = Color.parseColor("#FFF3DC")
    private val cDark = Color.parseColor("#5B3A1E")
    private val cIris = Color.parseColor("#5A341A")
    private val cPupil = Color.parseColor("#2A150A")
    private val cBeak = Color.parseColor("#FFA91F")
    private val cMouth = Color.parseColor("#8A2F2F")
    private val cAccent = Color.parseColor("#E8663D")

    private var last = 0L
    private var t = 0f
    private var blinkAt = 2.5f
    private var blinkStart = -1f
    private var lookX = 0f
    private var lookY = 0f
    private var lookTx = 0f
    private var lookTy = 0f
    private var nextLook = 2f
    private var mouth = 0f
    private var browTilt = 0f
    private var browLift = 0f
    private var cheek = 0.35f
    private var eyeScale = 1f

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        last = 0L
        invalidate()
    }

    private fun lerp(a: Float, b: Float, k: Float) = a + (b - a) * min(1f, k)

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else min(0.05f, (now - last) / 1e9f)
        last = now
        t += dt
        step(dt)
        render(c)
        postInvalidateOnAnimation()
    }

    private fun step(dt: Float) {
        val m = mode
        if (blinkStart < 0f && t >= blinkAt) blinkStart = t
        if (blinkStart >= 0f && t - blinkStart > 0.18f) {
            blinkStart = -1f
            blinkAt = t + 2.2f + (sin(t * 12.9f) * 0.5f + 0.5f) * 3f
        }
        var tilt = 0f
        var lift = 0f
        var mouthT = 0f
        var cheekT = 0.3f
        var eyeT = 1f
        when (m) {
            Mode.LISTENING -> {
                lookTx = -0.7f + 0.15f * sin(t * 2f); lookTy = -0.5f
                tilt = 0.8f; lift = 1f; mouthT = 0.3f; eyeT = 1.08f + max(0f, level) / 10f * 0.1f
            }
            Mode.THINKING -> {
                lookTx = 0.7f; lookTy = -0.8f
                tilt = -0.7f; mouthT = 0f; eyeT = 1f
            }
            Mode.SPEAKING -> {
                lookTx = 0.15f * sin(t * 1.5f); lookTy = 0f
                tilt = 0.1f * sin(t * 9f); lift = 0f
                mouthT = abs(sin(t * 11f)) * 0.7f + abs(sin(t * 17.3f)) * 0.3f
                cheekT = 0.6f
            }
            Mode.IDLE -> {
                if (t >= nextLook) {
                    lookTx = sin(t * 7.3f) * 0.8f
                    lookTy = sin(t * 3.1f) * 0.3f
                    nextLook = t + 1.8f + abs(sin(t * 5.1f)) * 2.5f
                }
            }
        }
        lookX = lerp(lookX, lookTx, dt * 6f)
        lookY = lerp(lookY, lookTy, dt * 6f)
        browTilt = lerp(browTilt, tilt, dt * 8f)
        browLift = lerp(browLift, lift, dt * 8f)
        mouth = lerp(mouth, mouthT, dt * 25f)
        cheek = lerp(cheek, cheekT, dt * 4f)
        eyeScale = lerp(eyeScale, eyeT, dt * 8f)
    }

    private fun render(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val s = min(w, h * 0.95f)
        val cx = w / 2f
        val speaking = mode == Mode.SPEAKING
        val bob = if (speaking) sin(t * 9f) * 0.01f * s else sin(t * 2f) * 0.008f * s
        val cy = h * 0.5f + bob

        paint.style = Paint.Style.FILL

        // shadow
        paint.color = Color.argb(35, 0, 0, 0)
        rect.set(cx - 0.4f * s, cy + 0.4f * s - bob, cx + 0.4f * s, cy + 0.46f * s - bob)
        c.drawOval(rect, paint)

        // tuft
        val wob = sin(t * (if (speaking) 9f else 2f)) * 4f
        paint.color = cDark
        for (a in floatArrayOf(-22f, 0f, 24f)) {
            c.save()
            c.rotate(a + wob, cx, cy - 0.34f * s)
            rect.set(cx - 0.018f * s, cy - 0.54f * s, cx + 0.018f * s, cy - 0.32f * s)
            c.drawOval(rect, paint)
            c.restore()
        }

        // head
        paint.color = cHead
        rect.set(cx - 0.43f * s, cy - 0.38f * s, cx + 0.43f * s, cy + 0.38f * s)
        c.drawOval(rect, paint)

        // feather spots
        paint.color = cSpot
        val spots = floatArrayOf(-0.2f, -0.3f, 0f, -0.33f, 0.2f, -0.3f, -0.33f, -0.18f, 0.33f, -0.18f)
        var i = 0
        while (i < spots.size) {
            rect.set(cx + spots[i] * s - 0.03f * s, cy + spots[i + 1] * s - 0.02f * s,
                cx + spots[i] * s + 0.03f * s, cy + spots[i + 1] * s + 0.02f * s)
            c.drawOval(rect, paint)
            i += 2
        }

        // cream face
        paint.color = cCream
        rect.set(cx - 0.34f * s, cy - 0.2f * s, cx + 0.34f * s, cy + 0.34f * s)
        c.drawOval(rect, paint)

        // eyes
        val ey = cy - 0.02f * s
        val exL = cx - 0.17f * s
        val exR = cx + 0.17f * s
        var closure = 0f
        if (blinkStart >= 0f) closure = sin(Math.PI.toFloat() * min(1f, (t - blinkStart) / 0.18f))
        eye(c, exL, ey, s, closure)
        eye(c, exR, ey, s, closure)

        // brows
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = 0.022f * s
        paint.color = cDark
        val by = ey - 0.17f * s - (eyeScale - 1f) * 0.2f * s
        val tl = browTilt * 0.04f * s
        val lf = browLift * 0.035f * s
        c.drawLine(exL - 0.08f * s, by + tl, exL + 0.08f * s, by - tl, paint)
        c.drawLine(exR - 0.08f * s, by - tl - lf, exR + 0.08f * s, by + tl - lf, paint)

        // cheeks
        paint.style = Paint.Style.FILL
        paint.color = Color.argb((cheek * 255).toInt().coerceIn(0, 255), 255, 120, 140)
        rect.set(cx - 0.33f * s, cy + 0.06f * s, cx - 0.21f * s, cy + 0.14f * s)
        c.drawOval(rect, paint)
        rect.set(cx + 0.21f * s, cy + 0.06f * s, cx + 0.33f * s, cy + 0.14f * s)
        c.drawOval(rect, paint)

        // beak
        val bx = cx
        val bY = cy + 0.085f * s
        val open = mouth * 0.07f * s
        val lowTop = bY + 0.012f * s + open
        if (open > 0.004f * s) {
            paint.color = cMouth
            rect.set(bx - 0.045f * s, bY + 0.005f * s, bx + 0.045f * s, lowTop + 0.02f * s)
            c.drawOval(rect, paint)
        }
        paint.color = cBeak
        path.reset()
        path.moveTo(bx - 0.05f * s, lowTop)
        path.lineTo(bx + 0.05f * s, lowTop)
        path.lineTo(bx, lowTop + 0.05f * s)
        path.close()
        c.drawPath(path, paint)
        path.reset()
        path.moveTo(bx - 0.075f * s, bY)
        path.quadTo(bx, bY - 0.035f * s, bx + 0.075f * s, bY)
        path.lineTo(bx, bY + 0.055f * s)
        path.close()
        c.drawPath(path, paint)

        // overlays
        when (mode) {
            Mode.LISTENING -> {
                val qx = cx - 0.4f * s
                val qy = cy - 0.36f * s + sin(t * 3f) * 0.012f * s
                paint.color = cAccent
                paint.alpha = (170 + 85 * sin(t * 4f)).toInt().coerceIn(0, 255)
                paint.textSize = 0.17f * s
                c.save()
                c.rotate(-15f, qx, qy)
                c.drawText("?", qx, qy, paint)
                c.restore()
                paint.alpha = 255
            }
            Mode.THINKING -> {
                paint.color = cAccent
                for (k in 0..2) {
                    val r = 0.012f * s + 0.01f * s * max(0f, sin(t * 6f - k * 0.9f))
                    c.drawCircle(cx + 0.33f * s + k * 0.055f * s, cy - 0.36f * s, r, paint)
                }
            }
            else -> {}
        }
    }

    private fun eye(c: Canvas, ex: Float, ey: Float, s: Float, closure: Float) {
        val rx = 0.105f * s * eyeScale
        val ry = 0.118f * s * eyeScale * (1f - 0.92f * closure)
        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE
        rect.set(ex - rx, ey - ry, ex + rx, ey + ry)
        c.drawOval(rect, paint)
        if (closure < 0.85f) {
            c.save()
            path.reset()
            path.addOval(rect, Path.Direction.CW)
            c.clipPath(path)
            val ix = ex + lookX * 0.03f * s
            val iy = ey + lookY * 0.035f * s
            paint.color = cIris
            c.drawCircle(ix, iy, 0.075f * s * eyeScale, paint)
            paint.color = cPupil
            c.drawCircle(ix, iy, 0.045f * s * eyeScale, paint)
            paint.color = Color.WHITE
            c.drawCircle(ix - 0.026f * s, iy - 0.03f * s, 0.022f * s, paint)
            c.drawCircle(ix + 0.02f * s, iy + 0.025f * s, 0.01f * s, paint)
            c.restore()
        } else {
            paint.style = Paint.Style.STROKE
            paint.strokeCap = Paint.Cap.ROUND
            paint.strokeWidth = 0.012f * s
            paint.color = cDark
            c.drawLine(ex - rx, ey, ex + rx, ey, paint)
            paint.style = Paint.Style.FILL
        }
    }
}
