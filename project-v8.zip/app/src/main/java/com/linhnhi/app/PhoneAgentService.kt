package com.linhnhi.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class PhoneAgentService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: PhoneAgentService? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 350)).build()
        return dispatchGesture(g, null, null)
    }

    private fun global(action: Int, okMsg: String): String =
        if (performGlobalAction(action)) okMsg else "❌ Không thực hiện được"

    fun doAction(a: String): String {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        return when (a) {
            "back" -> global(GLOBAL_ACTION_BACK, "⬅️ Đã quay lại")
            "home" -> global(GLOBAL_ACTION_HOME, "🏠 Về màn hình chính")
            "recents" -> global(GLOBAL_ACTION_RECENTS, "🗂 Mở đa nhiệm")
            "notifications" -> global(GLOBAL_ACTION_NOTIFICATIONS, "🔔 Mở thông báo")
            "quick_settings" -> global(GLOBAL_ACTION_QUICK_SETTINGS, "⚙️ Mở cài đặt nhanh")
            "lock" ->
                if (Build.VERSION.SDK_INT >= 28) global(GLOBAL_ACTION_LOCK_SCREEN, "🔒 Đã khóa màn hình")
                else "❌ Máy quá cũ, không khóa được"
            "screenshot" ->
                if (Build.VERSION.SDK_INT >= 28) global(GLOBAL_ACTION_TAKE_SCREENSHOT, "📸 Đã chụp màn hình")
                else "❌ Máy quá cũ, không chụp được"
            "scroll_down" -> if (swipe(w / 2, h * 0.7f, w / 2, h * 0.3f)) "⬇️ Đã cuộn xuống" else "❌ Không vuốt được"
            "scroll_up" -> if (swipe(w / 2, h * 0.3f, w / 2, h * 0.7f)) "⬆️ Đã cuộn lên" else "❌ Không vuốt được"
            "swipe_left" -> if (swipe(w * 0.8f, h / 2, w * 0.2f, h / 2)) "⬅️ Đã vuốt trái" else "❌ Không vuốt được"
            "swipe_right" -> if (swipe(w * 0.2f, h / 2, w * 0.8f, h / 2)) "➡️ Đã vuốt phải" else "❌ Không vuốt được"
            else -> "❌ Không hiểu lệnh: $a"
        }
    }

    fun clickText(t: String): String {
        val root = rootInActiveWindow ?: return "❌ Không đọc được màn hình"
        val nodes = root.findAccessibilityNodeInfosByText(t)
        for (n in nodes) {
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return "👆 Đã bấm \"$t\""
            }
        }
        return "❌ Không thấy nút \"$t\" trên màn hình"
    }

    fun typeText(t: String): String {
        val root = rootInActiveWindow ?: return "❌ Không đọc được màn hình"
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return "❌ Chưa chọn ô nhập chữ"
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        return if (f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) "⌨️ Đã nhập chữ" else "❌ Không nhập được"
    }
}
