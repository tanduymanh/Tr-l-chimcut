package com.linhnhi.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("remind", "Nhắc nhở", NotificationManager.IMPORTANCE_HIGH)
        )
        val n = Notification.Builder(c, "remind")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Chim Cút nhắc bạn")
            .setContentText(i.getStringExtra("msg") ?: "Đến giờ rồi!")
            .setAutoCancel(true)
            .build()
        nm.notify((System.currentTimeMillis() % 100000).toInt(), n)
    }
}
