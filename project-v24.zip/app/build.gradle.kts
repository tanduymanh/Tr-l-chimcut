plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.linhnhi.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.linhnhi.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 24
        versionName = "1.24"
    }
    signingConfigs {
        create("fixed") {
            storeFile = file("chimcut.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fixed")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
