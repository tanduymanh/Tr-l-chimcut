package com.linhnhi.app

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Settings
import java.text.Normalizer
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private val BG = Color.parseColor("#14142B")
    private val ACCENT = Color.parseColor("#6C63FF")
    private val CARD = Color.parseColor("#2A2A5A")
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT
    private val REQ_VOICE = 11
    private val DEFAULT_MODEL = "gemini-3.8-flash"
    private val DEFAULT_PROMPT =
        "Bạn là Chim Cút, trợ lý AI thân thiện nói tiếng Việt. Trả lời ngắn gọn, dễ hiểu."

    private lateinit var prefs: SharedPreferences
    private lateinit var content: FrameLayout
    private lateinit var chatView: LinearLayout
    private lateinit var chatList: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var input: EditText
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var player: MediaPlayer? = null
    private var systemPrompt = DEFAULT_PROMPT
    private val history = ArrayList<Pair<String, String>>()
    private var alarmId = 100

    private val assistants = listOf(
        Triple("🧑‍🏫 Gia sư tiếng Anh", "Bạn là gia sư tiếng Anh. Giải thích bằng tiếng Việt, cho ví dụ ngắn, sửa lỗi cho người học.", ""),
        Triple("💼 Tư vấn bán hàng", "Bạn là chuyên gia tư vấn bán hàng. Giúp viết kịch bản chốt đơn, xử lý từ chối, trả lời khách bằng tiếng Việt tự nhiên.", ""),
        Triple("🍳 Đầu bếp", "Bạn là đầu bếp. Gợi ý món ăn Việt dễ làm, nêu nguyên liệu và các bước ngắn gọn.", ""),
        Triple("🩺 Sức khỏe cơ bản", "Bạn cung cấp thông tin sức khỏe cơ bản bằng tiếng Việt, luôn nhắc đi khám bác sĩ khi có triệu chứng nghiêm trọng.", ""),
        Triple("✍️ Viết nội dung", "Bạn là copywriter tiếng Việt. Viết bài đăng, quảng cáo, caption hấp dẫn, ngắn gọn.", ""),
        Triple("💻 Lập trình", "Bạn là lập trình viên giàu kinh nghiệm. Giải thích bằng tiếng Việt, đưa code ngắn gọn, chạy được.", ""),
        Triple("👶 Kể chuyện cho bé", "Bạn kể chuyện cho trẻ em bằng tiếng Việt, ngắn, vui, có bài học nhẹ nhàng.", ""),
        Triple("🌐 Dịch thuật", "Bạn là phiên dịch. Dịch qua lại Việt - Anh chính xác, tự nhiên. Chỉ trả về bản dịch.", "")
    )

    private val stations = listOf(
        "VOV1 - Đài Tiếng nói Việt Nam" to "https://stream.vovmedia.vn/vov1",
        "VOV2 - Âm thanh Việt Nam" to "https://stream.vovmedia.vn/vov2",
        "VOV3 - Tiếng nói giải trí" to "https://stream.vovmedia.vn/vov3"
    )

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        tts = TextToSpeech(this, this)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val tabs = listOf<Pair<String, () -> Unit>>(
            "Chat" to { show(chatView) },
            "Trợ lý" to { show(buildAssistants()) },
            "Radio" to { show(buildRadio()) },
            "Nhắc" to { show(buildReminder()) },
            "Cài đặt" to { show(buildSettings()) }
        )
        for ((name, action) in tabs) {
            bar.addView(btn(name) { action() }.apply { textSize = 13f; maxLines = 1 }, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        root.addView(bar)
        setContentView(root)
        buildChat()
        show(chatView)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = (tts?.setLanguage(Locale("vi", "VN")) ?: -2) >= TextToSpeech.LANG_AVAILABLE
        }
    }

    override fun onDestroy() {
        player?.release()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun show(v: View) {
        content.removeAllViews()
        content.addView(v)
    }

    private fun btn(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        minWidth = 0
        minimumWidth = 0
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(ACCENT); cornerRadius = dp(10).toFloat() }
        setPadding(dp(8), dp(4), dp(8), dp(4))
        layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
        setOnClickListener { onClick() }
    }

    private fun edit(hint: String) = EditText(this).apply {
        this.hint = hint
        setTextColor(Color.WHITE)
        setHintTextColor(Color.GRAY)
    }

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 20f
        setTextColor(Color.WHITE)
        setPadding(0, dp(8), 0, dp(8))
    }

    private fun page(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
    }

    // ---------------- CHAT ----------------
    private fun buildChat() {
        chatView = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        chatScroll = ScrollView(this)
        chatList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(24), dp(8), dp(8))
        }
        chatScroll.addView(chatList)
        chatView.addView(chatScroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        input = edit("Nhập tin nhắn...")
        row.addView(input, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(btn("🎤") { startVoice() })
        row.addView(btn("Gửi") {
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) {
                input.setText("")
                send(t)
            }
        })
        chatView.addView(row)
        addBubble("Xin chào! Mình là Chim Cút. Thử nói: \"mở YouTube\", \"gọi cho mẹ\", \"cuộn xuống\", \"khóa màn hình\", \"chỉ đường đến chợ Bến Thành\".", false)
    }

    private fun addBubble(text: String, user: Boolean): TextView {
        val tv = TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = 16f
            maxWidth = (resources.displayMetrics.widthPixels * 0.85).toInt()
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                setColor(if (user) ACCENT else CARD)
                cornerRadius = dp(14).toFloat()
            }
        }
        val lp = LinearLayout.LayoutParams(WRAP, WRAP).apply {
            gravity = if (user) Gravity.END else Gravity.START
            setMargins(dp(4), dp(4), dp(4), dp(4))
        }
        chatList.addView(tv, lp)
        chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
        return tv
    }

    private class Reply(val text: String, val calls: List<Pair<String, JSONObject>>)

    private fun send(text: String) {
        show(chatView)
        val key = prefs.getString("key", "") ?: ""
        if (key.isBlank()) {
            Toast.makeText(this, "Hãy nhập API key trong Cài đặt", Toast.LENGTH_LONG).show()
            show(buildSettings())
            return
        }
        val model = currentModel()
        addBubble(text, true)
        history.add("user" to text)
        val tv = addBubble("...", false)
        Thread {
            var ok = true
            var reply = Reply("", emptyList())
            var err = ""
            try {
                reply = callGemini(key, model)
            } catch (e: Exception) {
                ok = false
                err = "⚠️ ${e.message}"
            }
            runOnUiThread {
                if (!ok) {
                    tv.text = err
                    history.removeAt(history.size - 1)
                    return@runOnUiThread
                }
                val hasCalls = reply.calls.isNotEmpty()
                tv.text = reply.text.ifBlank { if (hasCalls) "⚙️ Đang thực hiện..." else "(Không có phản hồi)" }
                history.add(
                    "model" to reply.text.ifBlank {
                        if (hasCalls) "Đã thực hiện: " + reply.calls.joinToString { it.first } else "(không có phản hồi)"
                    }
                )
                val handler = Handler(Looper.getMainLooper())
                reply.calls.forEachIndexed { i, c ->
                    handler.postDelayed({
                        val r = runTool(c.first, c.second)
                        addBubble(r, false)
                    }, i * 2000L)
                }
                if (prefs.getBoolean("tts", true) && ttsReady) {
                    val spoken = if (reply.text.isNotBlank()) reply.text else if (hasCalls) "Xong rồi" else ""
                    val clean = spoken.replace(Regex("[^\\p{L}\\p{N}\\s.,!?]"), "")
                    if (clean.isNotBlank()) tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "linhnhi")
                }
                chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
            }
        }.start()
    }

    private fun fn(name: String, desc: String, vararg params: Pair<String, String>): JSONObject {
        val props = JSONObject()
        val req = JSONArray()
        for ((k, d) in params) {
            props.put(k, JSONObject().put("type", "string").put("description", d))
            req.put(k)
        }
        val o = JSONObject().put("name", name).put("description", desc)
        if (params.isNotEmpty()) {
            o.put("parameters", JSONObject().put("type", "object").put("properties", props).put("required", req))
        }
        return o
    }

    private fun toolDecls(): JSONArray = JSONArray()
        .put(fn("open_app", "Mở một ứng dụng đã cài trên điện thoại", "app_name" to "Tên ứng dụng, ví dụ YouTube, Zalo, Camera"))
        .put(fn("call_phone", "Gọi điện cho một người trong danh bạ hoặc một số điện thoại", "contact" to "Tên người trong danh bạ hoặc số điện thoại"))
        .put(fn("send_sms", "Soạn tin nhắn SMS cho một người", "contact" to "Tên người hoặc số điện thoại", "message" to "Nội dung tin nhắn"))
        .put(fn("search_web", "Tìm kiếm trên Google", "query" to "Từ khóa tìm kiếm"))
        .put(fn("search_youtube", "Tìm video trên YouTube", "query" to "Từ khóa tìm kiếm"))
        .put(fn("navigate", "Chỉ đường hoặc tìm địa điểm trên bản đồ", "destination" to "Địa điểm cần đến"))
        .put(fn("set_timer", "Hẹn giờ nhắc sau một số phút", "minutes" to "Số phút, ví dụ 10", "message" to "Nội dung nhắc"))
        .put(
            fn(
                "phone_control",
                "Điều khiển điện thoại bằng cử chỉ hoặc nút hệ thống",
                "action" to "Một trong: back, home, recents, notifications, quick_settings, lock, screenshot, scroll_down, scroll_up, swipe_left, swipe_right"
            )
        )
        .put(fn("click_text", "Bấm vào nút hoặc chữ đang hiển thị trên màn hình", "text" to "Chữ trên nút cần bấm"))
        .put(fn("type_text", "Gõ chữ vào ô nhập đang được chọn", "text" to "Nội dung cần gõ"))

    private fun currentModel(): String {
        val m = prefs.getString("model", "") ?: ""
        return if (m.isBlank() || m == "gemini-2.5-flash") DEFAULT_MODEL else m
    }

    private fun postWithRetry(key: String, model: String, json: String): String {
        var attempt = 0
        while (true) {
            val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.connectTimeout = 20000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.outputStream.use { it.write(json.toByteArray()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream.bufferedReader().use { it.readText() }
            if (code in 200..299) return resp
            if ((code == 503 || code == 500 || code == 429) && attempt < 2) {
                attempt++
                Thread.sleep(2500L * attempt)
                continue
            }
            throw Exception(friendlyError(code, resp))
        }
    }

    private fun friendlyError(code: Int, resp: String): String {
        val msg = try {
            JSONObject(resp).optJSONObject("error")?.optString("message") ?: resp
        } catch (e: Exception) {
            resp
        }
        val hint = when (code) {
            503, 500 -> "Máy chủ Gemini đang quá tải, đã thử lại 3 lần. Chờ một lát rồi gửi lại."
            429 -> "Hết lượt miễn phí tạm thời. Chờ vài phút rồi thử lại."
            404 -> "Model này không còn dùng được. Vào Cài đặt đổi tên model."
            400, 401, 403 -> "API key sai hoặc không có quyền. Kiểm tra lại key trong Cài đặt."
            else -> "Lỗi máy chủ."
        }
        return "$hint (HTTP $code)\n" + msg.take(150)
    }

    private fun callGemini(key: String, model: String): Reply {
        val sys = systemPrompt + " Bạn đang chạy trong ứng dụng Android. Khi người dùng yêu cầu mở app, gọi điện, nhắn tin, " +
            "tìm kiếm, chỉ đường, hẹn giờ hoặc điều khiển điện thoại (vuốt, cuộn, quay lại, về màn hình chính, khóa máy), " +
            "hãy gọi hàm tương ứng thay vì chỉ trả lời bằng chữ."
        val body = JSONObject()
        body.put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
        body.put("tools", JSONArray().put(JSONObject().put("functionDeclarations", toolDecls())))
        val contents = JSONArray()
        for ((r, t) in history) {
            contents.put(
                JSONObject().put("role", r)
                    .put("parts", JSONArray().put(JSONObject().put("text", t)))
            )
        }
        body.put("contents", contents)
        val resp = postWithRetry(key, model, body.toString())
        val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        val calls = ArrayList<Pair<String, JSONObject>>()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (p.has("functionCall")) {
                val fc = p.getJSONObject("functionCall")
                calls.add(fc.getString("name") to (fc.optJSONObject("args") ?: JSONObject()))
            } else {
                sb.append(p.optString("text"))
            }
        }
        return Reply(sb.toString(), calls)
    }

    // ---------------- TOOLS ----------------
    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "").replace('đ', 'd').trim()

    private fun runTool(name: String, a: JSONObject): String {
        return try {
            when (name) {
                "open_app" -> openApp(a.optString("app_name"))
                "call_phone" -> {
                    val who = a.optString("contact")
                    val n = resolveNumber(who)
                        ?: return "❌ Không tìm thấy số của \"$who\" (cần cấp quyền Danh bạ rồi nói lại)"
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n")))
                    "📞 Đã mở cuộc gọi tới $who ($n), bấm gọi để kết nối"
                }
                "send_sms" -> {
                    val who = a.optString("contact")
                    val n = resolveNumber(who)
                        ?: return "❌ Không tìm thấy số của \"$who\" (cần cấp quyền Danh bạ rồi nói lại)"
                    startActivity(
                        Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n"))
                            .putExtra("sms_body", a.optString("message"))
                    )
                    "💬 Đã soạn tin cho $who, bấm gửi để hoàn tất"
                }
                "search_web" -> {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.optString("query")))))
                    "🔎 Đã tìm: ${a.optString("query")}"
                }
                "search_youtube" -> {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(a.optString("query")))))
                    "▶️ Đã tìm trên YouTube: ${a.optString("query")}"
                }
                "navigate" -> {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(a.optString("destination")))))
                    "🗺 Đã mở bản đồ: ${a.optString("destination")}"
                }
                "set_timer" -> {
                    val min = a.optString("minutes").toDoubleOrNull() ?: return "❌ Không hiểu số phút"
                    val msg = a.optString("message").ifBlank { "Hết giờ!" }
                    setAlarmAt(System.currentTimeMillis() + (min * 60000).toLong(), msg, null)
                    "⏰ Đã hẹn sau ${a.optString("minutes")} phút"
                }
                "phone_control" -> agent { it.doAction(a.optString("action")) }
                "click_text" -> agent { it.clickText(a.optString("text")) }
                "type_text" -> agent { it.typeText(a.optString("text")) }
                else -> "❌ Chưa hỗ trợ lệnh: $name"
            }
        } catch (e: Exception) {
            "❌ Lỗi: ${e.message}"
        }
    }

    private fun agent(block: (PhoneAgentService) -> String): String {
        val s = PhoneAgentService.instance
        if (s == null) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return "⚠️ Hãy bật \"Chim Cút Agent\" trong Trợ năng rồi thử lại"
        }
        return block(s)
    }

    private fun openApp(name: String): String {
        val pm = packageManager
        val q = norm(name)
        if (q.isBlank()) return "❌ Chưa biết mở app nào"
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { norm(it.loadLabel(pm).toString()) == q }
            ?: apps.firstOrNull { norm(it.loadLabel(pm).toString()).contains(q) }
            ?: apps.firstOrNull { val l = norm(it.loadLabel(pm).toString()); l.length >= 3 && q.contains(l) }
            ?: return "❌ Không tìm thấy app \"$name\""
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
            ?: return "❌ Không mở được app \"$name\""
        startActivity(i)
        return "📱 Đã mở ${hit.loadLabel(pm)}"
    }

    private fun resolveNumber(contact: String): String? {
        val t = contact.trim()
        if (Regex("^[0-9+ .\\-]{6,}$").matches(t)) return t.replace(Regex("[ .\\-]"), "")
        if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.READ_CONTACTS), 2)
            return null
        }
        val q = norm(t)
        val r = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
            null, null, null
        )?.use { cur ->
            var best: String? = null
            while (cur.moveToNext()) {
                val dn = norm(cur.getString(1) ?: "")
                if (dn == q) return@use cur.getString(0)
                if (best == null && dn.contains(q)) best = cur.getString(0)
            }
            best
        }
        return r?.replace(Regex("[ .\\-]"), "")
    }

    // ---------------- VOICE ----------------
    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN")
        try {
            startActivityForResult(i, REQ_VOICE)
        } catch (e: Exception) {
            Toast.makeText(this, "Máy không hỗ trợ nhận diện giọng nói", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VOICE && resultCode == RESULT_OK) {
            val t = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!t.isNullOrBlank()) send(t)
        }
    }

    // ---------------- ASSISTANTS ----------------
    private fun buildAssistants(): View {
        val sv = ScrollView(this)
        val p = page()
        p.addView(label("Danh sách trợ lý"))
        p.addView(btn("🤖 Chim Cút (mặc định)") { pickAssistant("Chim Cút", DEFAULT_PROMPT) })
        for ((name, prompt, _) in assistants) {
            p.addView(btn(name) { pickAssistant(name, prompt) })
        }
        sv.addView(p)
        return sv
    }

    private fun pickAssistant(name: String, prompt: String) {
        systemPrompt = prompt
        history.clear()
        chatList.removeAllViews()
        addBubble("Đã chuyển sang trợ lý: $name. Bạn muốn hỏi gì?", false)
        show(chatView)
    }

    // ---------------- RADIO ----------------
    private fun buildRadio(): View {
        val sv = ScrollView(this)
        val p = page()
        val status = TextView(this).apply { setTextColor(Color.LTGRAY); text = "Chọn một đài" }
        p.addView(label("Đài Radio Việt Nam"))
        p.addView(status)
        for ((name, url) in stations) p.addView(btn(name) { play(url, status) })
        val custom = edit("Dán link stream (mp3/aac) khác")
        p.addView(custom)
        p.addView(btn("Phát link này") {
            val u = custom.text.toString().trim()
            if (u.isNotEmpty()) play(u, status)
        })
        p.addView(btn("⏹ Dừng") {
            player?.release()
            player = null
            status.text = "Đã dừng"
        })
        sv.addView(p)
        return sv
    }

    private fun play(url: String, status: TextView) {
        player?.release()
        status.text = "Đang tải..."
        player = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA).build()
            )
            setOnPreparedListener { it.start(); status.text = "Đang phát: $url" }
            setOnErrorListener { _, _, _ -> status.text = "Không phát được (link hỏng?)"; true }
            try {
                setDataSource(url)
                prepareAsync()
            } catch (e: Exception) {
                status.text = "Lỗi: ${e.message}"
            }
        }
    }

    // ---------------- REMINDER ----------------
    private fun buildReminder(): View {
        val sv = ScrollView(this)
        val p = page()
        val msg = edit("Nội dung nhắc (vd: Uống thuốc)")
        val minutes = edit("Số phút (hẹn giờ)").apply { inputType = InputType.TYPE_CLASS_NUMBER }
        val list = TextView(this).apply { setTextColor(Color.LTGRAY); setPadding(0, dp(12), 0, 0) }
        p.addView(label("Lịch nhắc & Hẹn giờ"))
        p.addView(msg)
        p.addView(btn("Nhắc vào giờ cụ thể") {
            val c = Calendar.getInstance()
            TimePickerDialog(this, { _, h, m ->
                val t = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0)
                    if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_MONTH, 1)
                }
                setAlarmAt(t.timeInMillis, msg.text.toString().ifBlank { "Đến giờ rồi!" }, list)
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
        })
        p.addView(minutes)
        p.addView(btn("Hẹn giờ sau N phút") {
            val n = minutes.text.toString().toLongOrNull()
            if (n == null || n <= 0) {
                Toast.makeText(this, "Nhập số phút", Toast.LENGTH_SHORT).show()
            } else {
                setAlarmAt(
                    System.currentTimeMillis() + n * 60000,
                    msg.text.toString().ifBlank { "Hết giờ!" }, list
                )
            }
        })
        p.addView(list)
        sv.addView(p)
        return sv
    }

    private fun setAlarmAt(ms: Long, msg: String, list: TextView?) {
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            this, alarmId++,
            Intent(this, AlarmReceiver::class.java).putExtra("msg", msg),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        val t = SimpleDateFormat("HH:mm dd/MM", Locale.getDefault()).format(Date(ms))
        list?.append("⏰ $t - $msg\n")
        Toast.makeText(this, "Đã đặt nhắc lúc $t", Toast.LENGTH_SHORT).show()
    }

    // ---------------- SETTINGS ----------------
    private fun buildSettings(): View {
        val sv = ScrollView(this)
        val p = page()
        val key = edit("Gemini API key").apply { setText(prefs.getString("key", "")) }
        val model = edit("Tên model").apply { setText(currentModel()) }
        val speak = CheckBox(this).apply {
            text = "Đọc to câu trả lời"
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("tts", true)
        }
        p.addView(label("Cài đặt"))
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "?" }
        p.addView(TextView(this).apply { text = "Phiên bản $ver"; setTextColor(Color.LTGRAY) })
        p.addView(TextView(this).apply {
            text = "Lấy API key miễn phí tại aistudio.google.com/apikey"
            setTextColor(Color.LTGRAY)
        })
        p.addView(key)
        p.addView(model)
        p.addView(speak)
        p.addView(TextView(this).apply {
            text = "Để AI vuốt/cuộn/bấm được: bật Trợ năng \"Chim Cút Agent\". Để gọi theo tên: cấp quyền Danh bạ khi được hỏi."
            setTextColor(Color.LTGRAY)
        })
        p.addView(btn("Mở cài đặt Trợ năng") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        p.addView(btn("Lưu") {
            prefs.edit()
                .putString("key", key.text.toString().trim())
                .putString("model", model.text.toString().trim().ifBlank { DEFAULT_MODEL })
                .putBoolean("tts", speak.isChecked).apply()
            Toast.makeText(this, "Đã lưu", Toast.LENGTH_SHORT).show()
        })
        sv.addView(p)
        return sv
    }
}
