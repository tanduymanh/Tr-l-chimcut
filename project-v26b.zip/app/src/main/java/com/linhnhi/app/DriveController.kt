package com.linhnhi.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.Locale
import kotlin.math.PI
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

// Chế độ lái xe: màn hình ngang, đồng hồ + ngày âm lịch, chim cút, tốc độ GPS, bản đồ và dẫn đường
class DriveController(
    private val act: Activity,
    private val prefs: SharedPreferences,
    private val speak: (String) -> Unit,
    private val onToggleTalk: () -> Unit,
    private val onExit: () -> Unit,
    private val notify: (String) -> Unit
) : LocationListener {

    private class Step(val text: String, val lat: Double, val lon: Double, val dist: Double)

    private val ui = Handler(Looper.getMainLooper())
    private val density = act.resources.displayMetrics.density
    private val matchP = LinearLayout.LayoutParams.MATCH_PARENT
    private val wrapP = LinearLayout.LayoutParams.WRAP_CONTENT

    val root = LinearLayout(act)
    val quail = QuailView(act)
    val caption = TextView(act)
    val talkBtn = Button(act)
    private val map = MapTileView(act)
    private val clockTv = TextView(act)
    private val dateTv = TextView(act)
    private val lunarTv = TextView(act)
    private val speedTv = TextView(act)
    private val bannerTitle = TextView(act)
    private val bannerSub = TextView(act)
    private lateinit var vehicleBtn: TextView

    var active = false
        private set
    private var last: Location? = null
    private var lastGpsAt = 0L
    private var firstFix = true
    private var street = ""
    private var lastStreetAt = 0L
    private var lastStreetLat = 0.0
    private var lastStreetLon = 0.0
    private var pendingQuery: String? = null
    private var routePts: List<DoubleArray> = emptyList()
    private var steps: List<Step> = emptyList()
    private var nextIdx = 1
    private var totalDist = 0.0
    private var totalDur = 0.0
    private var destName = ""
    private var destLat = Double.NaN
    private var destLon = Double.NaN
    private val announced = HashSet<Int>()
    private var offCount = 0
    private var lastReroute = 0L
    private var lastDay = -1
    private var vehicle = prefs.getString("vehicle", "car") ?: "car"

    private val tick = object : Runnable {
        override fun run() {
            updateClock()
            ui.postDelayed(this, 1000)
        }
    }

    private fun dp(x: Int) = (x * density).toInt()

    private fun bg(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun roundBtn(label: String, onClick: () -> Unit): TextView = TextView(act).apply {
        text = label
        textSize = 18f
        gravity = Gravity.CENTER
        setTextColor(Color.parseColor("#4A2C12"))
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(240, 255, 255, 255))
            setStroke(dp(1), Color.argb(70, 0, 0, 0))
        }
        setOnClickListener { onClick() }
    }

    init {
        root.orientation = LinearLayout.HORIZONTAL
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#FFE9B8"), Color.parseColor("#FFB87A"))
        )

        // ----- cột trái -----
        val left = LinearLayout(act)
        left.orientation = LinearLayout.VERTICAL
        left.setPadding(dp(8), dp(6), dp(8), dp(6))

        val top = LinearLayout(act)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(roundBtn("←") { onExit() }, LinearLayout.LayoutParams(dp(40), dp(40)))
        clockTv.textSize = 32f
        clockTv.typeface = Typeface.DEFAULT_BOLD
        clockTv.setTextColor(Color.parseColor("#4A2C12"))
        clockTv.setPadding(dp(10), 0, dp(10), 0)
        top.addView(clockTv, LinearLayout.LayoutParams(wrapP, wrapP))
        val dateCol = LinearLayout(act)
        dateCol.orientation = LinearLayout.VERTICAL
        dateTv.textSize = 12f
        dateTv.setTextColor(Color.parseColor("#4A2C12"))
        lunarTv.textSize = 11f
        lunarTv.setTextColor(Color.parseColor("#8A4B12"))
        dateCol.addView(dateTv)
        dateCol.addView(lunarTv)
        top.addView(dateCol, LinearLayout.LayoutParams(0, wrapP, 1f))
        left.addView(top, LinearLayout.LayoutParams(matchP, wrapP))

        left.addView(quail, LinearLayout.LayoutParams(matchP, 0, 1f))

        caption.textSize = 14f
        caption.setTextColor(Color.parseColor("#4A2C12"))
        caption.gravity = Gravity.CENTER
        caption.minLines = 2
        caption.maxLines = 3
        caption.text = "Bấm nút để trò chuyện với Chim Cút"
        left.addView(caption, LinearLayout.LayoutParams(matchP, wrapP))

        talkBtn.isAllCaps = false
        talkBtn.textSize = 15f
        talkBtn.setTextColor(Color.WHITE)
        talkBtn.background = bg(Color.parseColor("#6C63FF"), 24)
        talkBtn.text = "🎙 Nói chuyện với Chim Cút"
        talkBtn.setOnClickListener { onToggleTalk() }
        left.addView(talkBtn, LinearLayout.LayoutParams(matchP, dp(46)).apply { topMargin = dp(4) })
        root.addView(left, LinearLayout.LayoutParams(0, matchP, 0.8f))

        // ----- cột phải: bản đồ -----
        val right = FrameLayout(act)
        right.addView(map, FrameLayout.LayoutParams(matchP, matchP))

        val speedCard = LinearLayout(act)
        speedCard.orientation = LinearLayout.HORIZONTAL
        speedCard.gravity = Gravity.CENTER_VERTICAL
        speedCard.background = bg(Color.argb(240, 255, 255, 255), 16)
        speedCard.setPadding(dp(12), dp(4), dp(14), dp(4))
        speedTv.text = "0"
        speedTv.textSize = 34f
        speedTv.typeface = Typeface.DEFAULT_BOLD
        speedTv.setTextColor(Color.parseColor("#1B3A6B"))
        speedCard.addView(speedTv, LinearLayout.LayoutParams(wrapP, wrapP))
        val unitCol = LinearLayout(act)
        unitCol.orientation = LinearLayout.VERTICAL
        unitCol.setPadding(dp(6), 0, 0, 0)
        val unit = TextView(act)
        unit.text = "km/h"
        unit.textSize = 14f
        unit.typeface = Typeface.DEFAULT_BOLD
        unit.setTextColor(Color.parseColor("#1E88E5"))
        val unitLabel = TextView(act)
        unitLabel.text = "TỐC ĐỘ XE"
        unitLabel.textSize = 9f
        unitLabel.setTextColor(Color.GRAY)
        unitCol.addView(unit)
        unitCol.addView(unitLabel)
        speedCard.addView(unitCol, LinearLayout.LayoutParams(wrapP, wrapP))
        right.addView(
            speedCard,
            FrameLayout.LayoutParams(wrapP, wrapP, Gravity.TOP or Gravity.START).apply { setMargins(dp(8), dp(8), 0, 0) }
        )

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        vehicleBtn = roundBtn(if (vehicle == "bike") "🏍" else "🚗") { toggleVehicle() }
        val buttons = listOf(
            roundBtn("✕") { stopNavigation() },
            vehicleBtn,
            roundBtn("🎯") { map.recenter(16) },
            roundBtn("＋") { map.zoomBy(1) },
            roundBtn("－") { map.zoomBy(-1) }
        )
        for (b in buttons) {
            col.addView(b, LinearLayout.LayoutParams(dp(40), dp(40)).apply { setMargins(0, dp(3), 0, dp(3)) })
        }
        right.addView(
            col,
            FrameLayout.LayoutParams(wrapP, wrapP, Gravity.TOP or Gravity.END).apply { setMargins(0, dp(4), dp(8), 0) }
        )

        val card = LinearLayout(act)
        card.orientation = LinearLayout.VERTICAL
        card.background = bg(Color.argb(245, 255, 255, 255), 14)
        card.setPadding(dp(14), dp(8), dp(14), dp(8))
        bannerTitle.textSize = 17f
        bannerTitle.typeface = Typeface.DEFAULT_BOLD
        bannerTitle.setTextColor(Color.parseColor("#1B1B1B"))
        bannerTitle.maxLines = 1
        bannerSub.textSize = 13f
        bannerSub.setTextColor(Color.DKGRAY)
        bannerSub.maxLines = 1
        card.addView(bannerTitle)
        card.addView(bannerSub)
        right.addView(
            card,
            FrameLayout.LayoutParams(matchP, wrapP, Gravity.BOTTOM).apply { setMargins(dp(8), 0, dp(60), dp(8)) }
        )
        root.addView(right, LinearLayout.LayoutParams(0, matchP, 1.3f))
        showIdleBanner()
    }

    // ---------- vòng đời ----------
    fun start() {
        active = true
        updateClock()
        ui.removeCallbacks(tick)
        ui.postDelayed(tick, 1000)
        startGps()
        if (steps.isEmpty()) showIdleBanner()
    }

    fun stop() {
        active = false
        ui.removeCallbacksAndMessages(null)
        stopGps()
    }

    fun pause() {
        ui.removeCallbacks(tick)
        stopGps()
    }

    fun resume() {
        if (!active) return
        ui.removeCallbacks(tick)
        ui.postDelayed(tick, 1000)
        startGps()
    }

    fun setTalkLabel(on: Boolean) {
        talkBtn.text = if (on) "⏹ Dừng trò chuyện" else "🎙 Nói chuyện với Chim Cút"
    }

    private fun note(msg: String) {
        act.runOnUiThread { notify(msg) }
    }

    private fun toggleVehicle() {
        vehicle = if (vehicle == "bike") "car" else "bike"
        prefs.edit().putString("vehicle", vehicle).apply()
        vehicleBtn.text = if (vehicle == "bike") "🏍" else "🚗"
        notify(if (vehicle == "bike") "🏍 Chế độ xe máy" else "🚗 Chế độ ô tô")
    }

    // ---------- đồng hồ + âm lịch ----------
    private fun updateClock() {
        val c = Calendar.getInstance()
        clockTv.text = String.format(Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
        val day = c.get(Calendar.DAY_OF_YEAR) + c.get(Calendar.YEAR) * 400
        if (day != lastDay) {
            lastDay = day
            val names = arrayOf("Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy")
            val wd = names[c.get(Calendar.DAY_OF_WEEK) - 1]
            val dd = c.get(Calendar.DAY_OF_MONTH)
            val mm = c.get(Calendar.MONTH) + 1
            val yy = c.get(Calendar.YEAR)
            dateTv.text = String.format(Locale.US, "%s, %02d/%02d/%d", wd, dd, mm, yy)
            val l = Lunar.solarToLunar(dd, mm, yy)
            lunarTv.text = "🌙 " + l[0] + "/" + l[1] + (if (l[3] == 1) " (nhuận)" else "") + " Âm lịch · " + Lunar.canChiYear(l[2])
        }
    }

    // ---------- GPS ----------
    @Suppress("MissingPermission")
    private fun startGps() {
        if (act.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        val lm = act.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            val gpsOn = lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
            if (gpsOn) lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this)
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000L, 0f, this)
            }
            if (last == null) {
                val k = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                    ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                if (k != null) onLocationChanged(k)
            }
            if (!gpsOn) note("⚠️ Hãy bật GPS (Vị trí) trong cài đặt của máy")
        } catch (e: SecurityException) {
        }
    }

    private fun stopGps() {
        try {
            val lm = act.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm.removeUpdates(this)
        } catch (e: Exception) {
        }
    }

    override fun onLocationChanged(loc: Location) {
        val now = SystemClock.elapsedRealtime()
        if (loc.provider == LocationManager.GPS_PROVIDER) {
            lastGpsAt = now
        } else if (now - lastGpsAt < 10000L) {
            return
        }
        last = loc
        val kmh = if (loc.hasSpeed()) (loc.speed * 3.6f).roundToInt() else 0
        speedTv.text = (if (kmh < 2) 0 else kmh).toString()
        val bearing = if (loc.hasBearing() && loc.speed > 1.5f) loc.bearing else map.carBearing
        map.setCar(loc.latitude, loc.longitude, bearing)
        if (firstFix) {
            firstFix = false
            map.recenter(16)
        }
        if (now - lastStreetAt > 15000L && dist(loc.latitude, loc.longitude, lastStreetLat, lastStreetLon) > 50.0) {
            lastStreetAt = now
            lastStreetLat = loc.latitude
            lastStreetLon = loc.longitude
            reverse(loc.latitude, loc.longitude)
        }
        pendingQuery?.let {
            pendingQuery = null
            navigateTo(it)
        }
        updateNav(loc)
    }

    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
    }

    override fun onProviderEnabled(provider: String) {
    }

    override fun onProviderDisabled(provider: String) {
    }

    // ---------- mạng ----------
    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "ChimCut/1.0 (personal Android assistant)")
        c.setRequestProperty("Accept-Language", "vi")
        c.connectTimeout = 10000
        c.readTimeout = 15000
        val code = c.responseCode
        if (code !in 200..299) throw Exception("HTTP $code")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private fun reverse(lat: Double, lon: Double) {
        Thread {
            try {
                val o = JSONObject(httpGet("https://nominatim.openstreetmap.org/reverse?lat=$lat&lon=$lon&format=jsonv2&zoom=17&accept-language=vi"))
                val ad = o.optJSONObject("address")
                var road = ""
                if (ad != null) {
                    for (k in arrayOf("road", "pedestrian", "suburb", "quarter", "village", "town", "city")) {
                        val v = ad.optString(k)
                        if (v.isNotBlank()) {
                            road = v
                            break
                        }
                    }
                }
                act.runOnUiThread {
                    street = road
                    if (steps.isEmpty()) showIdleBanner()
                }
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun showIdleBanner() {
        bannerTitle.text = "Vị trí hiện tại"
        bannerSub.text = if (street.isNotBlank()) street else "Đang xác định vị trí..."
    }

    // ---------- tìm đường ----------
    fun navigateTo(query: String) {
        val loc = last
        if (loc == null) {
            pendingQuery = query
            notify("📡 Đang chờ tín hiệu GPS, bạn ra chỗ thoáng giúp mình nhé...")
            return
        }
        notify("🧭 Đang tìm \"$query\"...")
        Thread {
            try {
                val d = 1.5
                val vb = (loc.longitude - d).toString() + "," + (loc.latitude + d) + "," + (loc.longitude + d) + "," + (loc.latitude - d)
                val arr = JSONArray(
                    httpGet(
                        "https://nominatim.openstreetmap.org/search?q=" + Uri.encode(query) +
                            "&format=jsonv2&limit=1&countrycodes=vn&accept-language=vi&viewbox=" + vb
                    )
                )
                if (arr.length() == 0) {
                    note("❌ Không tìm thấy địa điểm \"$query\"")
                    return@Thread
                }
                val o = arr.getJSONObject(0)
                var name = o.optString("name")
                if (name.isBlank()) name = o.optString("display_name").split(",").firstOrNull().orEmpty()
                if (name.isBlank()) name = query
                routeFrom(loc, o.getString("lat").toDouble(), o.getString("lon").toDouble(), name, true)
            } catch (e: Exception) {
                note("❌ Lỗi tìm đường: " + e.message)
            }
        }.start()
    }

    private fun routeFrom(from: Location, lat: Double, lon: Double, name: String, announce: Boolean) {
        try {
            val url = "https://router.project-osrm.org/route/v1/driving/" + from.longitude + "," + from.latitude + ";" + lon + "," + lat +
                "?overview=full&geometries=geojson&steps=true"
            val js = JSONObject(httpGet(url))
            if (js.optString("code") != "Ok") {
                note("❌ Không tìm được đường đi tới \"$name\"")
                return
            }
            val r = js.getJSONArray("routes").getJSONObject(0)
            val coords = r.getJSONObject("geometry").getJSONArray("coordinates")
            val pts = ArrayList<DoubleArray>(coords.length())
            for (i in 0 until coords.length()) {
                val c = coords.getJSONArray(i)
                pts.add(doubleArrayOf(c.getDouble(1), c.getDouble(0)))
            }
            val stepsJs = r.getJSONArray("legs").getJSONObject(0).getJSONArray("steps")
            val st = ArrayList<Step>()
            for (i in 0 until stepsJs.length()) {
                val s = stepsJs.getJSONObject(i)
                val mn = s.getJSONObject("maneuver")
                val loc = mn.getJSONArray("location")
                st.add(Step(describe(mn, s.optString("name")), loc.getDouble(1), loc.getDouble(0), s.optDouble("distance", 0.0)))
            }
            val distance = r.getDouble("distance")
            val duration = r.getDouble("duration")
            act.runOnUiThread { applyRoute(pts, st, distance, duration, name, lat, lon, announce) }
        } catch (e: Exception) {
            note("❌ Lỗi tìm đường: " + e.message)
        }
    }

    private fun describe(mn: JSONObject, road: String): String {
        val type = mn.optString("type")
        if (type == "arrive") return "Bạn đã đến nơi"
        val turn = when (mn.optString("modifier")) {
            "left" -> "Rẽ trái"
            "right" -> "Rẽ phải"
            "slight left" -> "Chếch sang trái"
            "slight right" -> "Chếch sang phải"
            "sharp left" -> "Rẽ gấp sang trái"
            "sharp right" -> "Rẽ gấp sang phải"
            "uturn" -> "Quay đầu"
            "straight" -> "Đi thẳng"
            else -> "Đi tiếp"
        }
        val base = when (type) {
            "depart" -> "Xuất phát"
            "roundabout", "rotary" -> {
                val ex = mn.optInt("exit", 0)
                if (ex > 0) "Vào vòng xuyến, ra lối thứ $ex" else "Vào vòng xuyến"
            }
            "exit roundabout", "exit rotary" -> "Ra khỏi vòng xuyến"
            "merge" -> "Nhập làn"
            "on ramp" -> "Đi vào đường nhánh"
            "off ramp" -> "Ra đường nhánh"
            "new name", "continue" -> "Đi tiếp"
            else -> turn
        }
        return if (road.isNotBlank() && type != "depart") "$base vào $road" else base
    }

    private fun applyRoute(
        pts: List<DoubleArray>, st: List<Step>, distance: Double, duration: Double,
        name: String, lat: Double, lon: Double, announce: Boolean
    ) {
        routePts = pts
        steps = st
        totalDist = distance
        totalDur = duration
        destName = name
        destLat = lat
        destLon = lon
        nextIdx = if (st.size > 1) 1 else 0
        announced.clear()
        offCount = 0
        map.setRoute(pts)
        map.setDest(lat, lon)
        if (announce) {
            map.fitRoute()
            ui.postDelayed({ if (steps.isNotEmpty()) map.recenter(16) }, 7000L)
            speak("Đến $name còn " + spDist(distance) + ", khoảng " + fmtMin(duration) + ".")
            notify("🧭 " + name + ": " + fmtDist(distance) + ", " + fmtMin(duration))
        }
        last?.let { updateNav(it) }
    }

    fun stopNavigation() {
        routePts = emptyList()
        steps = emptyList()
        announced.clear()
        destLat = Double.NaN
        destLon = Double.NaN
        map.setRoute(null)
        map.clearDest()
        showIdleBanner()
    }

    private fun updateNav(loc: Location) {
        val st = steps
        if (st.isEmpty()) return
        val now = SystemClock.elapsedRealtime()
        var minD = Double.MAX_VALUE
        for (p in routePts) {
            val dd = dist(loc.latitude, loc.longitude, p[0], p[1])
            if (dd < minD) minD = dd
        }
        if (minD > 120.0) offCount++ else offCount = 0
        if (offCount >= 4 && now - lastReroute > 20000L && !destLat.isNaN()) {
            lastReroute = now
            offCount = 0
            speak("Bạn đi lệch đường, mình tìm lại đường nhé.")
            val dLat = destLat
            val dLon = destLon
            val dName = destName
            Thread { routeFrom(loc, dLat, dLon, dName, false) }.start()
            return
        }
        var idx = nextIdx.coerceIn(0, st.size - 1)
        var dn = dist(loc.latitude, loc.longitude, st[idx].lat, st[idx].lon)
        if (dn < 25.0 && idx < st.size - 1) {
            nextIdx = idx + 1
            idx = nextIdx
            dn = dist(loc.latitude, loc.longitude, st[idx].lat, st[idx].lon)
        }
        val s = st[idx]
        if (idx == st.size - 1 && dn < 40.0) {
            speak("Bạn đã đến nơi.")
            notify("🏁 Đã đến $destName")
            stopNavigation()
            return
        }
        var remain = dn
        for (k in idx until st.size) remain += st[k].dist
        val remSec = if (totalDist > 0) totalDur * remain / totalDist else 0.0
        bannerTitle.text = s.text
        bannerSub.text = fmtDist(dn) + " · còn " + fmtDist(remain) + " · " + fmtMin(remSec)
        if (dn <= 250.0 && announced.add(idx)) speak("Sau " + spDist(dn) + ", " + s.text)
    }

    // ---------- định dạng ----------
    private fun dist(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371000.0
        val p1 = Math.toRadians(lat1)
        val p2 = Math.toRadians(lat2)
        val dp = Math.toRadians(lat2 - lat1)
        val dl = Math.toRadians(lon2 - lon1)
        val a = sin(dp / 2) * sin(dp / 2) + cos(p1) * cos(p2) * sin(dl / 2) * sin(dl / 2)
        return 2 * r * asin(sqrt(a))
    }

    private fun fmtDist(m: Double): String =
        if (m < 1000) "${max(10, (m / 10).roundToInt() * 10)} m"
        else String.format(Locale.US, "%.1f", m / 1000).replace('.', ',') + " km"

    private fun spDist(m: Double): String =
        if (m < 1000) "${max(10, (m / 10).roundToInt() * 10)} mét"
        else String.format(Locale.US, "%.1f", m / 1000).replace('.', ',') + " ki lô mét"

    private fun fmtMin(sec: Double): String {
        val mnt = (sec / 60).roundToInt()
        return if (mnt >= 60) "${mnt / 60} giờ ${mnt % 60} phút" else "$mnt phút"
    }
}
