package com.linhnhi.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.LruCache
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.tan

// Bản đồ OpenStreetMap tự vẽ: tải ô bản đồ (tile), kéo để di chuyển, chụm để zoom, vẽ xe và tuyến đường
class MapTileView(ctx: Context) : View(ctx) {

    var zoom = 16
        private set
    var follow = true
    var carBearing = 0f
        private set

    private var cLat = 21.0278
    private var cLon = 105.8342
    private var carLat = Double.NaN
    private var carLon = Double.NaN
    private var route: List<DoubleArray>? = null
    private var destLat = Double.NaN
    private var destLon = Double.NaN

    private val density = resources.displayMetrics.density
    private val sc = (density / 1.3f).coerceIn(1f, 2.2f)
    private val ts = 256.0 * sc

    private val tiles = LruCache<String, Bitmap>(220)
    private val loading = HashSet<String>()
    private val pool = Executors.newFixedThreadPool(4)
    private val dir = File(ctx.cacheDir, "tiles")

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tilePaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val path = Path()
    private val dst = RectF()
    private val bgColor = Color.parseColor("#E8E4DC")

    private var lx = 0f
    private var ly = 0f
    private var dragging = false
    private var pinch = 1f
    private val scaler = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            pinch *= d.scaleFactor
            return true
        }

        override fun onScaleEnd(d: ScaleGestureDetector) {
            val dz = (ln(pinch.toDouble()) / ln(2.0)).roundToInt()
            pinch = 1f
            if (dz != 0) setZoom(zoom + dz)
        }
    })

    init {
        dir.mkdirs()
        pool.execute {
            try {
                val files = dir.listFiles() ?: emptyArray()
                if (files.size > 3000) {
                    files.sortBy { it.lastModified() }
                    for (i in 0 until files.size / 2) files[i].delete()
                }
            } catch (e: Exception) {
            }
        }
    }

    // ---------- toạ độ ----------
    private fun worldX(lon: Double, z: Int) = (lon + 180.0) / 360.0 * (1 shl z) * ts

    private fun worldY(lat: Double, z: Int): Double {
        val r = Math.toRadians(lat)
        return (1.0 - ln(tan(r) + 1.0 / cos(r)) / PI) / 2.0 * (1 shl z) * ts
    }

    private fun lonOf(x: Double, z: Int) = x / ((1 shl z) * ts) * 360.0 - 180.0

    private fun latOf(y: Double, z: Int): Double {
        val n = PI - 2.0 * PI * y / ((1 shl z) * ts)
        return Math.toDegrees(atan(0.5 * (exp(n) - exp(-n))))
    }

    // ---------- điều khiển ----------
    fun setCar(lat: Double, lon: Double, bearing: Float) {
        carLat = lat
        carLon = lon
        carBearing = bearing
        invalidate()
    }

    fun setRoute(r: List<DoubleArray>?) {
        route = r
        invalidate()
    }

    fun setDest(lat: Double, lon: Double) {
        destLat = lat
        destLon = lon
        invalidate()
    }

    fun clearDest() {
        destLat = Double.NaN
        destLon = Double.NaN
        invalidate()
    }

    fun setZoom(z: Int) {
        zoom = z.coerceIn(3, 19)
        invalidate()
    }

    fun zoomBy(d: Int) = setZoom(zoom + d)

    fun recenter(z: Int = 0) {
        follow = true
        if (z > 0) setZoom(z) else invalidate()
    }

    fun fitRoute() {
        val r = route ?: return
        if (r.size < 2 || width <= 0 || height <= 0) return
        var minLat = 90.0
        var maxLat = -90.0
        var minLon = 180.0
        var maxLon = -180.0
        for (p in r) {
            minLat = min(minLat, p[0])
            maxLat = max(maxLat, p[0])
            minLon = min(minLon, p[1])
            maxLon = max(maxLon, p[1])
        }
        follow = false
        cLat = (minLat + maxLat) / 2
        cLon = (minLon + maxLon) / 2
        var z = 18
        while (z > 3) {
            val dx = worldX(maxLon, z) - worldX(minLon, z)
            val dy = worldY(minLat, z) - worldY(maxLat, z)
            if (dx < width * 0.75 && dy < height * 0.65) break
            z--
        }
        setZoom(z)
    }

    // ---------- tải ô bản đồ ----------
    private fun request(z: Int, x: Int, y: Int, key: String) {
        if (loading.contains(key)) return
        loading.add(key)
        pool.execute {
            val bmp = loadTile(z, x, y)
            post {
                if (bmp != null) tiles.put(key, bmp)
                loading.remove(key)
                invalidate()
            }
        }
    }

    private fun loadTile(z: Int, x: Int, y: Int): Bitmap? {
        val f = File(dir, "t_${z}_${x}_$y.png")
        if (f.exists()) {
            val b = BitmapFactory.decodeFile(f.path)
            if (b != null) return b
        }
        return try {
            val conn = URL("https://tile.openstreetmap.org/$z/$x/$y.png").openConnection() as HttpURLConnection
            conn.setRequestProperty("User-Agent", "ChimCut/1.0 (personal Android assistant)")
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            if (conn.responseCode == 200) {
                val bytes = conn.inputStream.readBytes()
                try {
                    f.writeBytes(bytes)
                } catch (e: Exception) {
                }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    // ---------- vẽ ----------
    override fun onDraw(c: Canvas) {
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return
        c.drawColor(bgColor)
        if (follow && !carLat.isNaN()) {
            cLat = carLat
            cLon = carLon
        }
        val z = zoom
        val cx = worldX(cLon, z)
        val cy = worldY(cLat, z)
        val left = cx - w / 2.0
        val top = cy - h / 2.0
        val n = 1 shl z
        val x0 = floor(left / ts).toInt()
        val x1 = floor((left + w) / ts).toInt()
        val y0 = floor(top / ts).toInt()
        val y1 = floor((top + h) / ts).toInt()
        for (ty in y0..y1) {
            if (ty < 0 || ty >= n) continue
            for (tx in x0..x1) {
                val wx = ((tx % n) + n) % n
                val key = "$z/$wx/$ty"
                val bmp = tiles.get(key)
                if (bmp != null) {
                    val px = (tx * ts - left).toFloat()
                    val py = (ty * ts - top).toFloat()
                    dst.set(px, py, px + ts.toFloat(), py + ts.toFloat())
                    c.drawBitmap(bmp, null, dst, tilePaint)
                } else {
                    request(z, wx, ty, key)
                }
            }
        }

        // tuyến đường
        val r = route
        if (r != null && r.size > 1) {
            path.reset()
            var first = true
            for (p in r) {
                val x = (worldX(p[1], z) - left).toFloat()
                val y = (worldY(p[0], z) - top).toFloat()
                if (first) {
                    path.moveTo(x, y)
                    first = false
                } else {
                    path.lineTo(x, y)
                }
            }
            paint.style = Paint.Style.STROKE
            paint.strokeCap = Paint.Cap.ROUND
            paint.strokeJoin = Paint.Join.ROUND
            paint.color = Color.WHITE
            paint.strokeWidth = 11f * density
            c.drawPath(path, paint)
            paint.color = Color.parseColor("#1E88E5")
            paint.strokeWidth = 7f * density
            c.drawPath(path, paint)
        }

        // điểm đến
        if (!destLat.isNaN()) {
            val x = (worldX(destLon, z) - left).toFloat()
            val y = (worldY(destLat, z) - top).toFloat()
            paint.style = Paint.Style.FILL
            paint.color = Color.WHITE
            c.drawCircle(x, y, 13f * density, paint)
            paint.color = Color.parseColor("#E53935")
            c.drawCircle(x, y, 10f * density, paint)
            paint.color = Color.WHITE
            c.drawCircle(x, y, 4f * density, paint)
        }

        // xe
        if (!carLat.isNaN()) {
            val x = (worldX(carLon, z) - left).toFloat()
            val y = (worldY(carLat, z) - top).toFloat()
            c.save()
            c.rotate(carBearing, x, y)
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(60, 33, 150, 243)
            c.drawCircle(x, y, 24f * density, paint)
            path.reset()
            path.moveTo(x, y - 19f * density)
            path.lineTo(x + 13f * density, y + 14f * density)
            path.lineTo(x, y + 7f * density)
            path.lineTo(x - 13f * density, y + 14f * density)
            path.close()
            paint.color = Color.WHITE
            c.drawPath(path, paint)
            path.reset()
            path.moveTo(x, y - 14f * density)
            path.lineTo(x + 9f * density, y + 10f * density)
            path.lineTo(x, y + 5f * density)
            path.lineTo(x - 9f * density, y + 10f * density)
            path.close()
            paint.color = Color.parseColor("#1565C0")
            c.drawPath(path, paint)
            c.restore()
        }
    }

    // ---------- cảm ứng ----------
    private fun panBy(dx: Float, dy: Float) {
        val z = zoom
        val nx = worldX(cLon, z) + dx
        val ny = worldY(cLat, z) + dy
        cLon = lonOf(nx, z)
        cLat = latOf(ny, z).coerceIn(-85.0, 85.0)
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaler.onTouchEvent(e)
        if (scaler.isInProgress || e.pointerCount > 1) {
            dragging = false
            lx = e.x
            ly = e.y
            return true
        }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lx = e.x
                ly = e.y
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lx
                val dy = e.y - ly
                if (!dragging && (abs(dx) > 8f || abs(dy) > 8f)) dragging = true
                if (dragging) {
                    follow = false
                    panBy(-dx, -dy)
                    lx = e.x
                    ly = e.y
                }
            }
        }
        return true
    }
}
