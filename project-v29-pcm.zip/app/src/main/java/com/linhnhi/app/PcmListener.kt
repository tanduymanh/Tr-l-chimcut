package com.linhnhi.app

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import java.io.ByteArrayOutputStream

/**
 * Thu âm bằng AudioRecord thay cho SpeechRecognizer.
 * AudioRecord không xin quyền âm thanh (audio focus) nên video đang phát KHÔNG bị dừng.
 * Lớp này chỉ cắt giọng nói thành từng đoạn PCM 16 kHz mono và gọi onSegment; việc chép lời
 * do nơi gọi làm (gửi lên Gemini).
 */
class PcmListener(
    private val onSegment: (ByteArray) -> Unit,
    private val keepGoing: () -> Boolean,
    private val onEnd: () -> Unit
) {
    @Volatile private var running = false
    @Volatile private var stopRequested = false
    val isRunning: Boolean get() = running

    private val rate = 16000
    private val frame = rate / 50 // 20 ms
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null

    fun start(): Boolean {
        if (running) return true
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return false
        val rec = createRecord(maxOf(minBuf * 4, rate)) ?: return false
        running = true
        stopRequested = false
        val t = Thread { loop(rec) }
        t.isDaemon = true
        t.start()
        return true
    }

    fun stop() {
        stopRequested = true
        running = false
    }

    @SuppressLint("MissingPermission")
    private fun createRecord(bufBytes: Int): AudioRecord? {
        val sources = intArrayOf(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.MIC
        )
        for (src in sources) {
            try {
                val r = AudioRecord(src, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufBytes)
                if (r.state == AudioRecord.STATE_INITIALIZED) return r
                r.release()
            } catch (e: Exception) {
            }
        }
        return null
    }

    private fun attachEffects(rec: AudioRecord) {
        try {
            if (AcousticEchoCanceler.isAvailable()) {
                aec = AcousticEchoCanceler.create(rec.audioSessionId)
                aec?.setEnabled(true)
            }
        } catch (e: Exception) {
        }
        try {
            if (NoiseSuppressor.isAvailable()) {
                ns = NoiseSuppressor.create(rec.audioSessionId)
                ns?.setEnabled(true)
            }
        } catch (e: Exception) {
        }
    }

    private fun writeFrame(out: ByteArrayOutputStream, f: ShortArray) {
        val b = ByteArray(f.size * 2)
        for (i in f.indices) {
            val v = f[i].toInt()
            b[2 * i] = (v and 0xFF).toByte()
            b[2 * i + 1] = ((v shr 8) and 0xFF).toByte()
        }
        out.write(b, 0, b.size)
    }

    private fun loop(rec: AudioRecord) {
        val buf = ShortArray(frame)
        val pre = ArrayDeque<ShortArray>()
        val sentAt = ArrayDeque<Long>()
        var seg = ByteArrayOutputStream()
        var inSpeech = false
        var loud = 0
        var quiet = 0
        var segMs = 0
        var base = -1.0
        var tick = 0
        try {
            attachEffects(rec)
            rec.startRecording()
            while (running) {
                val n = rec.read(buf, 0, frame)
                if (n < 0) break
                if (n == 0) continue
                val cur = buf.copyOf(n)
                var sum = 0.0
                for (v in cur) sum += v.toDouble() * v.toDouble()
                val rms = Math.sqrt(sum / n)
                if (base < 0) base = maxOf(rms, 100.0)
                val thr = maxOf(MIN_RMS, base * RATIO)
                if (!inSpeech) {
                    pre.addLast(cur)
                    while (pre.size > PRE_FRAMES) pre.removeFirst()
                    if (rms > thr) loud++ else loud = 0
                    if (loud >= ONSET_FRAMES) {
                        inSpeech = true
                        seg = ByteArrayOutputStream()
                        quiet = 0
                        for (f in pre) writeFrame(seg, f)
                        segMs = pre.size * 20
                        pre.clear()
                    }
                } else {
                    writeFrame(seg, cur)
                    segMs += 20
                    if (rms < thr * 0.6) quiet++ else quiet = 0
                    if (quiet >= END_QUIET_FRAMES || segMs >= MAX_MS) {
                        inSpeech = false
                        loud = 0
                        if (segMs - quiet * 20 >= MIN_MS) {
                            val now = System.currentTimeMillis()
                            while (sentAt.isNotEmpty() && now - sentAt.first() > 60000L) sentAt.removeFirst()
                            if (sentAt.size < MAX_PER_MIN) {
                                sentAt.addLast(now)
                                onSegment(seg.toByteArray())
                            }
                        }
                        segMs = 0
                        quiet = 0
                    }
                }
                // nền chậm: theo dõi mức âm thanh video để chỉ bắt giọng to hơn hẳn
                base = base * 0.985 + rms * 0.015
                tick++
                if (tick % 50 == 0 && !keepGoing()) break
            }
        } catch (e: Exception) {
        } finally {
            try {
                rec.stop()
            } catch (e: Exception) {
            }
            try {
                aec?.release()
            } catch (e: Exception) {
            }
            try {
                ns?.release()
            } catch (e: Exception) {
            }
            rec.release()
            val wasStopped = stopRequested
            running = false
            if (!wasStopped) onEnd()
        }
    }

    companion object {
        private const val MIN_RMS = 400.0
        private const val RATIO = 1.7
        private const val PRE_FRAMES = 12
        private const val ONSET_FRAMES = 4
        private const val END_QUIET_FRAMES = 30
        private const val MIN_MS = 500
        private const val MAX_MS = 7000
        private const val MAX_PER_MIN = 10
    }
}
