package com.linhnhi.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import java.text.Normalizer
import java.util.Locale

class PhoneAgentService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: PhoneAgentService? = null
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---------- tiện ích ----------
    private fun norm(s: CharSequence?): String {
        if (s == null) return ""
        return Normalizer.normalize(s.toString().lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "").replace('đ', 'd').trim()
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 350)).build()
        return dispatchGesture(g, null, null)
    }

    private fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build()
        return dispatchGesture(g, null, null)
    }

    private fun global(action: Int, okMsg: String): String =
        if (performGlobalAction(action)) okMsg else "❌ Không thực hiện được"

    private fun collect(n: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (out.size > 500 || depth > 45) return
        out.add(n)
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            collect(c, out, depth + 1)
        }
    }

    private fun allNodes(): List<AccessibilityNodeInfo> {
        val list = ArrayList<AccessibilityNodeInfo>()
        val root = activeRoot() ?: return list
        collect(root, list, 0)
        return list
    }

    private fun label(n: AccessibilityNodeInfo): String {
        val parts = ArrayList<String>()
        n.text?.let { if (it.isNotBlank()) parts.add(it.toString()) }
        n.contentDescription?.let { if (it.isNotBlank()) parts.add(it.toString()) }
        if (Build.VERSION.SDK_INT >= 26) {
            n.hintText?.let { if (it.isNotBlank()) parts.add(it.toString()) }
        }
        return parts.joinToString(" | ")
    }

    private fun findByLabel(query: String): AccessibilityNodeInfo? {
        val q = norm(query)
        if (q.isEmpty()) return null
        var best: AccessibilityNodeInfo? = null
        var bestScore = Int.MAX_VALUE
        for (n in allNodes()) {
            if (!n.isVisibleToUser) continue
            val l = norm(label(n))
            if (l.isEmpty() || !l.contains(q)) continue
            val score = (if (l == q) 0 else 1 + (l.length - q.length)) + (if (n.isClickable) 0 else 50)
            if (score < bestScore) {
                best = n
                bestScore = score
            }
        }
        return best
    }

    private fun findEditable(): AccessibilityNodeInfo? =
        allNodes().firstOrNull {
            it.isVisibleToUser && (it.isEditable || it.className?.toString()?.contains("EditText") == true)
        }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        var depth = 0
        while (c != null && depth < 8) {
            if (c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            c = c.parent
            depth++
        }
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.width() > 0 && r.height() > 0) return tap(r.exactCenterX(), r.exactCenterY())
        return false
    }

    // ---------- lệnh ----------
    fun doAction(a: String): String {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        return when (a) {
            "back" -> global(GLOBAL_ACTION_BACK, "⬅️ Đã quay lại")
            "home" -> global(GLOBAL_ACTION_HOME, "🏠 Về màn hình chính")
            "recents" -> global(GLOBAL_ACTION_RECENTS, "🗂 Mở đa nhiệm")
            "notifications" -> global(GLOBAL_ACTION_NOTIFICATIONS, "🔔 Mở thông báo")
            "quick_settings" -> global(GLOBAL_ACTION_QUICK_SETTINGS, "⚙️ Mở cài đặt nhanh")
            "lock" ->
                if (Build.VERSION.SDK_INT >= 28) global(GLOBAL_ACTION_LOCK_SCREEN, "🔒 Đã khóa màn hình")
                else "❌ Máy quá cũ, không khóa được"
            "screenshot" ->
                if (Build.VERSION.SDK_INT >= 28) global(GLOBAL_ACTION_TAKE_SCREENSHOT, "📸 Đã chụp màn hình")
                else "❌ Máy quá cũ, không chụp được"
            "scroll_down" -> if (swipe(w / 2, h * 0.7f, w / 2, h * 0.3f)) "⬇️ Đã cuộn xuống" else "❌ Không vuốt được"
            "scroll_up" -> if (swipe(w / 2, h * 0.3f, w / 2, h * 0.7f)) "⬆️ Đã cuộn lên" else "❌ Không vuốt được"
            "swipe_left" -> if (swipe(w * 0.8f, h / 2, w * 0.2f, h / 2)) "⬅️ Đã vuốt trái" else "❌ Không vuốt được"
            "swipe_right" -> if (swipe(w * 0.2f, h / 2, w * 0.8f, h / 2)) "➡️ Đã vuốt phải" else "❌ Không vuốt được"
            else -> "❌ Không hiểu lệnh: $a"
        }
    }

    fun doActionRepeat(a: String, times: Int): String {
        val n = times.coerceIn(1, 10)
        val first = doAction(a)
        for (i in 1 until n) {
            handler.postDelayed({ doAction(a) }, i * 700L)
        }
        return if (n > 1) "$first (x$n)" else first
    }

    fun clickText(t: String): String {
        val n = findByLabel(t) ?: return "❌ Không thấy \"$t\" trên màn hình"
        return if (clickNode(n)) "👆 Đã bấm \"$t\"" else "❌ Thấy \"$t\" nhưng không bấm được"
    }

    fun typeText(t: String, submit: Boolean = false): String {
        val root = activeRoot() ?: return "❌ Không đọc được màn hình"
        var f: AccessibilityNodeInfo? = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (f == null || !f.isEditable) f = findEditable()
        if (f == null) return "❌ Không thấy ô nhập chữ trên màn hình"
        f.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        if (!f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) {
            return "❌ Không nhập được chữ vào ô này"
        }
        if (submit) handler.postDelayed({ pressEnter() }, 500)
        return "⌨️ Đã nhập \"$t\"" + (if (submit) " và bấm tìm" else "")
    }

    private fun pressEnter() {
        val f = findEditable() ?: return
        var done = false
        if (Build.VERSION.SDK_INT >= 30) {
            done = f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        if (!done) {
            val other = findByLabel("tìm kiếm")
            if (other != null && other != f) clickNode(other)
        }
    }

    fun searchInApp(query: String, done: (String) -> Unit) {
        val start = findEditable() ?: findByLabel("tìm kiếm") ?: findByLabel("search") ?: findByLabel("tìm")
        if (start == null) {
            done("❌ Không thấy ô hay nút tìm kiếm. Hãy nói \"đọc màn hình\" để mình xem có gì.")
            return
        }
        clickNode(start)
        var attempts = 0
        val step = object : Runnable {
            override fun run() {
                attempts++
                if (findEditable() != null) {
                    done(typeText(query, true))
                    return
                }
                if (attempts >= 4) {
                    done("❌ Đã bấm tìm kiếm nhưng không thấy ô nhập chữ")
                    return
                }
                handler.postDelayed(this, 900)
            }
        }
        handler.postDelayed(step, 900)
    }

    private fun activeRoot(): AccessibilityNodeInfo? {
        rootInActiveWindow?.let { return it }
        val ws = try {
            windows
        } catch (e: Exception) {
            return null
        }
        var best: AccessibilityNodeInfo? = null
        var bestLayer = -1
        for (w in ws) {
            if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
            val r = w.root ?: continue
            if (r.packageName?.toString() == packageName) continue
            if (w.layer > bestLayer) {
                best = r
                bestLayer = w.layer
            }
        }
        return best
    }

    private fun <T> poll(times: Int, interval: Long, check: () -> T?, then: (T?) -> Unit) {
        var n = 0
        val r = object : Runnable {
            override fun run() {
                val v = check()
                if (v != null) {
                    then(v)
                    return
                }
                n++
                if (n >= times) {
                    then(null)
                    return
                }
                handler.postDelayed(this, interval)
            }
        }
        handler.postDelayed(r, interval)
    }

    private fun isEditNode(n: AccessibilityNodeInfo): Boolean =
        n.isEditable || n.className?.toString()?.contains("EditText") == true

    private fun findResult(contact: String): AccessibilityNodeInfo? {
        val q = norm(contact)
        if (q.isEmpty()) return null
        var best: AccessibilityNodeInfo? = null
        var bestScore = Int.MAX_VALUE
        for (n in allNodes()) {
            if (!n.isVisibleToUser || isEditNode(n)) continue
            val l = norm(label(n))
            if (l.isEmpty() || !l.contains(q)) continue
            val score = (if (l == q) 0 else 1 + (l.length - q.length)) + (if (n.isClickable) 0 else 30)
            if (score < bestScore) {
                best = n
                bestScore = score
            }
        }
        return best
    }

    private fun findComposer(): AccessibilityNodeInfo? =
        allNodes().firstOrNull { n ->
            n.isVisibleToUser && isEditNode(n) && norm(label(n)).let {
                !(it.contains("tim kiem") || it.contains("tim ") || it.contains("search"))
            }
        }

    private fun findExact(vararg names: String): AccessibilityNodeInfo? {
        val set = names.map { norm(it) }.toSet()
        for (n in allNodes()) {
            if (!n.isVisibleToUser) continue
            val parts = label(n).split(" | ").map { norm(it) }
            if (parts.any { it in set }) return n
        }
        return null
    }

    private fun hasUserText(ed: AccessibilityNodeInfo): Boolean {
        ed.refresh()
        if (Build.VERSION.SDK_INT >= 26 && ed.isShowingHintText) return false
        return ed.text?.toString()?.trim().orEmpty().isNotEmpty()
    }

    private fun fillComposer(ed: AccessibilityNodeInfo, message: String): String {
        ed.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, message)
        return if (ed.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) {
            "✍️ Đã điền vào ô nhập: \"$message\""
        } else {
            "❌ Không điền được vào ô nhập tin nhắn"
        }
    }

    fun inChat(): Boolean {
        val root = activeRoot() ?: return false
        if (root.packageName?.toString() == packageName) return false
        return findComposer() != null
    }

    private fun chatTitle(): String {
        val dm = resources.displayMetrics
        val limit = dm.heightPixels * 0.14f
        for (n in allNodes()) {
            if (!n.isVisibleToUser || isEditNode(n)) continue
            val t = n.text?.toString()?.trim() ?: continue
            if (t.isEmpty() || t.length > 40) continue
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.bottom < limit * 1.3f && r.left > dm.widthPixels * 0.08f && r.right < dm.widthPixels * 0.85f) return t
        }
        return ""
    }

    fun screenContext(): String {
        val root = activeRoot() ?: return ""
        val pkg = root.packageName?.toString() ?: return ""
        if (pkg == packageName) return ""
        val chat = findComposer() != null
        if (!chat) return "Ngữ cảnh màn hình hiện tại: đang mở app $pkg, không thấy ô nhập tin nhắn."
        val title = chatTitle()
        return "Ngữ cảnh màn hình hiện tại: đang mở app $pkg, đang ở khung chat" +
            (if (title.isNotBlank()) " với \"$title\"" else "") + " (có ô nhập tin nhắn)."
    }

    fun composeMessage(message: String, done: (String) -> Unit) {
        val ed = findComposer()
        if (ed != null) {
            done(fillComposer(ed, message))
            return
        }
        val trigger = findByLabel("nhắn tin") ?: findByLabel("tin nhắn") ?: findByLabel("message")
        if (trigger == null) {
            done("❌ Không thấy ô nhập tin nhắn. Bạn mở khung chat trước nhé.")
            return
        }
        clickNode(trigger)
        poll(5, 700, { findComposer() }) { e ->
            if (e == null) {
                done("❌ Không mở được ô nhập tin nhắn")
            } else {
                done(fillComposer(e, message))
            }
        }
    }

    fun sendCurrent(done: (String) -> Unit) {
        val ed = findComposer()
        if (ed == null) {
            done("❌ Không thấy ô nhập tin nhắn")
            return
        }
        if (clickSend(ed)) {
            done("✅ Đã bấm gửi")
        } else {
            done("⚠️ Không thấy nút gửi hoặc ô nhập đang trống, bạn bấm gửi giúp mình nhé")
        }
    }

    private fun clickSend(ed: AccessibilityNodeInfo): Boolean {
        if (!hasUserText(ed)) return false
        findExact("gửi", "send", "gửi tin nhắn", "send message")?.let {
            if (clickNode(it)) return true
        }
        val er = Rect()
        ed.getBoundsInScreen(er)
        var cand: AccessibilityNodeInfo? = null
        var candLeft = -1
        for (n in allNodes()) {
            if (!n.isVisibleToUser || !n.isClickable || n == ed) continue
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.width() <= 0 || r.height() <= 0) continue
            val sameRow = r.centerY() >= er.top - er.height() && r.centerY() <= er.bottom + er.height()
            if (sameRow && r.centerX() > er.centerX() && r.left > candLeft) {
                cand = n
                candLeft = r.left
            }
        }
        if (cand != null && clickNode(cand)) return true
        if (Build.VERSION.SDK_INT >= 30) {
            return ed.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        return false
    }

    fun sendMessage(contact: String, message: String, done: (String) -> Unit) {
        searchInApp(contact) { r1 ->
            if (r1.startsWith("❌")) {
                done(r1)
                return@searchInApp
            }
            poll(7, 900, { findResult(contact) }) { hit ->
                if (hit == null) {
                    done("❌ Không thấy \"$contact\" trong kết quả tìm kiếm")
                    return@poll
                }
                clickNode(hit)
                poll(8, 900, { findComposer() }) { ed ->
                    if (ed == null) {
                        done("❌ Không mở được khung chat với $contact")
                        return@poll
                    }
                    val b = Bundle()
                    b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, message)
                    ed.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                    if (!ed.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) {
                        done("❌ Không gõ được tin nhắn vào khung chat")
                        return@poll
                    }
                    handler.postDelayed({
                        val ed2 = findComposer() ?: ed
                        ed2.refresh()
                        if (clickSend(ed2)) {
                            done("✅ Đã bấm gửi tin cho $contact: \"$message\"")
                        } else {
                            done("⚠️ Đã gõ tin nhưng không thấy nút gửi, bạn bấm gửi giúp mình nhé")
                        }
                    }, 800)
                }
            }
        }
    }

    fun readScreen(): String {
        val seen = LinkedHashSet<String>()
        for (n in allNodes()) {
            if (!n.isVisibleToUser) continue
            val l = label(n)
            val flag = (if (n.isClickable) "C" else "") + (if (n.isEditable) "E" else "")
            if (l.isBlank() && n.isEditable) {
                seen.add("• (ô nhập) [E]")
            } else if (l.isNotBlank()) {
                seen.add("• " + l.replace('\n', ' ').take(40) + (if (flag.isNotEmpty()) " [$flag]" else ""))
            }
            if (seen.size >= 35) break
        }
        if (seen.isEmpty()) return "❌ Không đọc được nội dung màn hình (app có thể chặn)"
        return "📋 Trên màn hình " + (activeRoot()?.packageName ?: "") + " (C = bấm được, E = ô nhập):\n" + seen.joinToString("\n")
    }
}
