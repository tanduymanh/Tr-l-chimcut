plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.linhnhi.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.linhnhi.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 35
        versionName = "1.34"
    }
    signingConfigs {
        create("fixed") {
            storeFile = file("chimcut.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fixed")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

tasks.matching { it.name == "validateSigningDebug" }.configureEach {
    doFirst {
        val ks = file("chimcut.keystore")
        if (!ks.exists()) {
            exec {
                commandLine(
                    "keytool", "-genkeypair", "-v",
                    "-keystore", ks.absolutePath,
                    "-alias", "androiddebugkey",
                    "-keyalg", "RSA",
                    "-keysize", "2048",
                    "-validity", "10000",
                    "-storepass", "android",
                    "-keypass", "android",
                    "-dname", "CN=ChimCut, OU=Dev, O=ChimCut, L=HN, S=HN, C=VN"
                )
            }
        }
    }
}
