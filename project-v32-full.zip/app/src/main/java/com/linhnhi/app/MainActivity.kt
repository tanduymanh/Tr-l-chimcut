package com.linhnhi.app

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import java.text.Normalizer
import android.graphics.Color
import android.graphics.PixelFormat
import android.view.MotionEvent
import kotlin.math.abs
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private val BG = Color.parseColor("#14142B")
    private val ACCENT = Color.parseColor("#6C63FF")
    private val CARD = Color.parseColor("#2A2A5A")
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT
    private val REQ_VOICE = 11
    private val DEFAULT_MODEL = "gemini-3.5-flash-lite"
    private val FALLBACK_MODELS = listOf("gemini-3.8-flash", "gemini-3.1-flash-lite")
    private val DEFAULT_PROMPT =
        "Bạn là Chim Cút, một chú chim cút đáng yêu, trợ lý AI nói tiếng Việt. Xưng \"mình\", gọi người dùng là \"bạn\", giọng vui vẻ, thân thiện, trả lời ngắn gọn dễ hiểu."

    private lateinit var prefs: SharedPreferences
    private lateinit var content: FrameLayout
    private lateinit var chatView: LinearLayout
    private lateinit var chatList: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var input: EditText
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var player: MediaPlayer? = null
    private var systemPrompt = DEFAULT_PROMPT
    private val history = ArrayList<Pair<String, String>>()
    private var alarmId = 100

    private val assistants = listOf(
        Triple("🧑‍🏫 Gia sư tiếng Anh", "Bạn là gia sư tiếng Anh. Giải thích bằng tiếng Việt, cho ví dụ ngắn, sửa lỗi cho người học.", ""),
        Triple("💼 Tư vấn bán hàng", "Bạn là chuyên gia tư vấn bán hàng. Giúp viết kịch bản chốt đơn, xử lý từ chối, trả lời khách bằng tiếng Việt tự nhiên.", ""),
        Triple("🍳 Đầu bếp", "Bạn là đầu bếp. Gợi ý món ăn Việt dễ làm, nêu nguyên liệu và các bước ngắn gọn.", ""),
        Triple("🩺 Sức khỏe cơ bản", "Bạn cung cấp thông tin sức khỏe cơ bản bằng tiếng Việt, luôn nhắc đi khám bác sĩ khi có triệu chứng nghiêm trọng.", ""),
        Triple("✍️ Viết nội dung", "Bạn là copywriter tiếng Việt. Viết bài đăng, quảng cáo, caption hấp dẫn, ngắn gọn.", ""),
        Triple("💻 Lập trình", "Bạn là lập trình viên giàu kinh nghiệm. Giải thích bằng tiếng Việt, đưa code ngắn gọn, chạy được.", ""),
        Triple("👶 Kể chuyện cho bé", "Bạn kể chuyện cho trẻ em bằng tiếng Việt, ngắn, vui, có bài học nhẹ nhàng.", ""),
        Triple("🌐 Dịch thuật", "Bạn là phiên dịch. Dịch qua lại Việt - Anh chính xác, tự nhiên. Chỉ trả về bản dịch.", "")
    )

    private val stations = listOf(
        "VOV1 - Đài Tiếng nói Việt Nam" to "https://stream.vovmedia.vn/vov1",
        "VOV2 - Âm thanh Việt Nam" to "https://stream.vovmedia.vn/vov2",
        "VOV3 - Tiếng nói giải trí" to "https://stream.vovmedia.vn/vov3"
    )

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        tts = TextToSpeech(this, this)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabBar = bar
        val tabs = listOf<Pair<String, () -> Unit>>(
            "Chim" to { show(quailTab) },
            "Chat" to { show(chatView) },
            "Trợ lý" to { show(buildAssistants()) },
            "Radio" to { show(buildRadio()) },
            "Nhắc" to { show(buildReminder()) },
            "Cài đặt" to { show(buildSettings()) }
        )
        for ((name, action) in tabs) {
            bar.addView(
                btn(name) { action() }.apply { textSize = 11.5f; maxLines = 1; setPadding(dp(2), dp(8), dp(2), dp(8)) },
                LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(1), dp(1), dp(1), dp(1)) }
            )
        }
        root.addView(bar)
        setContentView(root)
        buildChat()
        buildQuail()
        show(quailTab)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = (tts?.setLanguage(Locale("vi", "VN")) ?: -2) >= TextToSpeech.LANG_AVAILABLE
            applyVoice()
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) {
                    if (id == "quail") runOnUiThread { onChunkDone() }
                }
                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) {
                    if (id == "quail") runOnUiThread { onChunkDone() }
                }
            })
        }
    }

    override fun onPause() {
        if (voiceOn && !floating) stopConversation()
        if (driveActive) drive?.pause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (floating) {
            stopFloating(false)
            show(quailTab)
        }
        if (driveActive) drive?.resume()
        if (pendingDrive) {
            pendingDrive = false
            enterDrive()
        }
        if (pendingNavDest != null) runPendingNav()
    }

    override fun onBackPressed() {
        if (driveActive) exitDrive() else super.onBackPressed()
    }

    override fun startActivity(intent: Intent?) {
        if (floating && intent != null) {
            applicationContext.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } else {
            super.startActivity(intent)
        }
    }

    override fun onDestroy() {
        hideBubble()
        stopService(Intent(this, ChimService::class.java))
        recognizer?.destroy()
        player?.release()
        tts?.shutdown()
        super.onDestroy()
    }

    private fun show(v: View) {
        content.removeAllViews()
        content.addView(v)
    }

    private fun btn(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        minWidth = 0
        minimumWidth = 0
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(ACCENT); cornerRadius = dp(10).toFloat() }
        setPadding(dp(8), dp(4), dp(8), dp(4))
        layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
        setOnClickListener { onClick() }
    }

    private fun edit(hint: String) = EditText(this).apply {
        this.hint = hint
        setTextColor(Color.WHITE)
        setHintTextColor(Color.GRAY)
    }

    private fun label(t: String) = TextView(this).apply {
        text = t
        textSize = 20f
        setTextColor(Color.WHITE)
        setPadding(0, dp(8), 0, dp(8))
    }

    private fun page(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
    }

    // ---------------- CHAT ----------------
    private fun buildChat() {
        chatView = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        chatScroll = ScrollView(this)
        chatList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(24), dp(8), dp(8))
        }
        chatScroll.addView(chatList)
        chatView.addView(chatScroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        input = edit("Nhập tin nhắn...")
        row.addView(input, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(btn("🎤") { startVoice() })
        row.addView(btn("Gửi") {
            val t = input.text.toString().trim()
            if (t.isNotEmpty()) {
                input.setText("")
                send(t)
            }
        })
        chatView.addView(row)
        addBubble("Xin chào! Mình là Chim Cút. Thử nói: \"mở YouTube\", \"gọi cho mẹ\", \"cuộn xuống\", \"khóa màn hình\", \"chỉ đường đến chợ Bến Thành\".", false)
    }

    private fun addBubble(text: String, user: Boolean): TextView {
        val tv = TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = 16f
            maxWidth = (resources.displayMetrics.widthPixels * 0.85).toInt()
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                setColor(if (user) ACCENT else CARD)
                cornerRadius = dp(14).toFloat()
            }
        }
        val lp = LinearLayout.LayoutParams(WRAP, WRAP).apply {
            gravity = if (user) Gravity.END else Gravity.START
            setMargins(dp(4), dp(4), dp(4), dp(4))
        }
        chatList.addView(tv, lp)
        chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
        return tv
    }

    private class Reply(val text: String, val calls: List<Pair<String, JSONObject>>)

    private fun send(text: String) {
        show(chatView)
        val key = prefs.getString("key", "") ?: ""
        if (key.isBlank()) {
            Toast.makeText(this, "Hãy nhập API key trong Cài đặt", Toast.LENGTH_LONG).show()
            show(buildSettings())
            return
        }
        val model = currentModel()
        addBubble(text, true)
        val pr = handlePendingSend(text)
        if (pr != null) {
            addBubble(pr, false)
            return
        }
        val qk = quickCall(text) ?: quickCommand(text)
        if (qk != null) {
            addBubble(qk, false)
            return
        }
        screenCtx = ""
        lastSpokenText = text
        history.add("user" to text)
        val tv = addBubble("...", false)
        Thread {
            var ok = true
            var reply = Reply("", emptyList())
            var err = ""
            try {
                reply = callGemini(key, model)
            } catch (e: Exception) {
                ok = false
                err = "⚠️ ${e.message}"
            }
            runOnUiThread {
                if (!ok) {
                    tv.text = err
                    history.removeAt(history.size - 1)
                    return@runOnUiThread
                }
                val hasCalls = reply.calls.isNotEmpty()
                tv.text = reply.text.ifBlank { if (hasCalls) "⚙️ Đang thực hiện..." else "(Không có phản hồi)" }
                if (hasCalls) {
                    if (history.isNotEmpty()) history.removeAt(history.size - 1)
                } else {
                    history.add("model" to reply.text.ifBlank { "(không có phản hồi)" })
                }
                val handler = Handler(Looper.getMainLooper())
                val starts = callStarts(reply.calls)
                reply.calls.forEachIndexed { i, c ->
                    handler.postDelayed({
                        val r = runTool(c.first, c.second)
                        addBubble(r, false)
                    }, starts[i])
                }
                if (prefs.getBoolean("tts", true) && ttsReady) {
                    val spoken = if (reply.text.isNotBlank()) reply.text else if (hasCalls) "Xong rồi" else ""
                    val clean = spoken.replace(Regex("[^\\p{L}\\p{N}\\s.,!?]"), "")
                    if (clean.isNotBlank()) tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "linhnhi")
                }
                chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
            }
        }.start()
    }

    private fun fn(name: String, desc: String, vararg params: Pair<String, String>): JSONObject {
        val props = JSONObject()
        val req = JSONArray()
        for ((k, d) in params) {
            props.put(k, JSONObject().put("type", "string").put("description", d))
            req.put(k)
        }
        val o = JSONObject().put("name", name).put("description", desc)
        if (params.isNotEmpty()) {
            o.put("parameters", JSONObject().put("type", "object").put("properties", props).put("required", req))
        }
        return o
    }

    private fun fn2(name: String, desc: String, req: List<Pair<String, String>>, opt: List<Pair<String, String>>): JSONObject {
        val props = JSONObject()
        val rq = JSONArray()
        for ((k, d) in req) {
            props.put(k, JSONObject().put("type", "string").put("description", d))
            rq.put(k)
        }
        for ((k, d) in opt) props.put(k, JSONObject().put("type", "string").put("description", d))
        val o = JSONObject().put("name", name).put("description", desc)
        if (props.length() > 0) {
            o.put("parameters", JSONObject().put("type", "object").put("properties", props).put("required", rq))
        }
        return o
    }

    private fun toolDecls(): JSONArray = JSONArray()
        .put(fn("open_app", "Mở một ứng dụng đã cài trên điện thoại", "app_name" to "Tên ứng dụng, ví dụ YouTube, Zalo, Camera"))
        .put(fn("call_phone", "Gọi điện cho một người trong danh bạ hoặc một số điện thoại", "contact" to "Tên người trong danh bạ hoặc số điện thoại"))
        .put(fn("send_sms", "Soạn tin nhắn SMS cho một người", "contact" to "Tên người hoặc số điện thoại", "message" to "Nội dung tin nhắn"))
        .put(fn("open_contacts", "Mở ứng dụng Danh bạ trên điện thoại"))
        .put(fn("call_zalo", "Gọi điện (gọi thoại) cho một người qua Zalo: mở Zalo, tìm người đó rồi bấm nút gọi. Chỉ dùng khi người dùng nói rõ gọi qua Zalo", "contact" to "Tên người trong Zalo"))
        .put(fn("search_web", "Mở trình duyệt tìm kiếm Google. CHỈ dùng khi câu người dùng có từ \"tìm\" hoặc \"tìm kiếm\"", "query" to "Từ khóa tìm kiếm"))
        .put(fn("search_youtube", "Tìm video trên YouTube", "query" to "Từ khóa tìm kiếm"))
        .put(fn("navigate", "Chỉ đường đến một địa điểm bằng ứng dụng Google Maps (dẫn đường bằng giọng nói của Google Maps)", "destination" to "Tên địa điểm hoặc địa chỉ cần đến, ví dụ chợ Bến Thành"))
        .put(fn("stop_navigation", "Dừng chỉ đường đang chạy trong chế độ lái xe"))
        .put(fn("drive_mode", "Bật chế độ lái xe (màn hình ngang có bản đồ, tốc độ, đồng hồ)"))
        .put(fn("set_timer", "Hẹn giờ nhắc sau một số phút", "minutes" to "Số phút, ví dụ 10", "message" to "Nội dung nhắc"))
        .put(
            JSONObject().put("name", "phone_control")
                .put(
                    "description",
                    "Điều khiển điện thoại bằng cử chỉ hoặc nút hệ thống. Ánh xạ theo hướng nội dung: \"cuộn xuống\", \"vuốt xuống\", \"xuống\" = scroll_down (xem phần nội dung bên dưới); " +
                        "\"cuộn lên\", \"vuốt lên\", \"lên\" = scroll_up (xem phần nội dung phía trên); \"quay lại\" = back; \"về màn hình chính\" = home; \"mở khóa\" = unlock (bật màn hình và vuốt mở khóa, không nhập mã)."
                )
                .put(
                    "parameters",
                    JSONObject().put("type", "object")
                        .put(
                            "properties",
                            JSONObject()
                                .put("action", JSONObject().put("type", "string").put("description", "Một trong: back, home, recents, notifications, quick_settings, lock, unlock, screenshot, scroll_down, scroll_up, swipe_left, swipe_right"))
                                .put("times", JSONObject().put("type", "string").put("description", "Số lần lặp lại, mặc định 1"))
                        )
                        .put("required", JSONArray().put("action"))
                )
        )
        .put(fn("click_text", "Bấm vào nút, biểu tượng hoặc chữ đang hiển thị trên màn hình (khớp theo chữ hoặc mô tả)", "text" to "Chữ hoặc tên nút cần bấm, ví dụ Tìm kiếm, Gửi"))
        .put(fn("type_text", "Gõ chữ vào ô nhập đang có trên màn hình", "text" to "Nội dung cần gõ"))
        .put(fn("search_in_app", "Tìm kiếm bên trong ứng dụng đang mở (ví dụ tìm tên người trong Zalo, Facebook): tự bấm ô tìm kiếm, gõ chữ và bấm tìm", "query" to "Nội dung cần tìm, ví dụ tên người"))
        .put(fn("read_screen", "Đọc các nút và chữ đang hiển thị trên màn hình điện thoại để biết có gì"))
        .put(fn("send_message_in_app", "Soạn và gửi tin nhắn cho một người trong ứng dụng nhắn tin Zalo hoặc Messenger/Facebook", "app" to "Zalo hoặc Messenger hoặc Facebook", "contact" to "Tên người nhận như hiển thị trong app", "message" to "Nội dung tin nhắn, đúng lời người dùng dặn"))
        .put(fn("compose_message", "Điền nội dung tin nhắn vào ô nhập của khung chat đang mở trên màn hình (Zalo, Messenger...), chưa gửi", "message" to "Nội dung tin nhắn cần điền, đúng lời người dùng"))
        .put(fn("call_control", "Nhận (answer), từ chối (reject) hoặc kết thúc (end) cuộc gọi đang đổ chuông hoặc đang diễn ra", "action" to "answer, reject hoặc end"))
        .put(
            fn2(
                "set_alarm", "Đặt báo thức trong app Đồng hồ của điện thoại",
                listOf("time" to "Giờ báo thức dạng 24 giờ HH:MM, ví dụ 06:00 hoặc 18:30"),
                listOf(
                    "label" to "Tên chuông báo, ví dụ Thi kiểm tra; bỏ trống nếu người dùng không nói",
                    "days" to "Lặp lại: daily hoặc danh sách T2,T3,T4,T5,T6,T7,CN; bỏ trống nếu chỉ báo một lần"
                )
            )
        )
        .put(
            fn2(
                "alarm_off", "Tắt báo thức trong app Đồng hồ (đang kêu, sắp tới, theo giờ, theo tên hoặc tất cả)",
                emptyList(),
                listOf("which" to "all, giờ HH:MM, hoặc tên báo thức; bỏ trống nếu đang có báo thức kêu hoặc báo thức sắp tới")
            )
        )
        .put(fn("alarm_on", "Bật lại một báo thức đã có trong app Đồng hồ", "which" to "Giờ HH:MM hoặc tên báo thức"))
        .put(fn("show_alarms", "Mở danh sách báo thức trong app Đồng hồ"))

    private class ApiError(val code: Int, msg: String) : Exception(msg)

    private fun modelChain(): List<String> {
        val saved = prefs.getString("model", "") ?: ""
        val old = setOf("", "gemini-2.5-flash", "gemini-3.8-flash")
        val first = if (saved in old) DEFAULT_MODEL else saved
        return (listOfNotNull(okModel) + listOf(first) + FALLBACK_MODELS).distinct()
    }

    @Volatile private var okModel: String? = null

    private fun currentModel(): String = modelChain().first()

    private fun rawPost(key: String, model: String, json: String): String {
        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.connectTimeout = 10000
        conn.readTimeout = 25000
        conn.doOutput = true
        conn.outputStream.use { it.write(json.toByteArray()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val resp = stream.bufferedReader().use { it.readText() }
        if (code in 200..299) return resp
        throw ApiError(code, friendlyError(code, resp))
    }

    private fun stripThinking(json: String): String =
        JSONObject(json).apply { remove("generationConfig") }.toString()

    private fun postOnce(key: String, model: String, json: String): String {
        try {
            return rawPost(key, model, json)
        } catch (e: ApiError) {
            if (e.code == 400 && json.contains("thinkingConfig")) return rawPost(key, model, stripThinking(json))
            throw e
        }
    }

    private fun streamRaw(key: String, model: String, json: String, onText: (String) -> Unit): Reply {
        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse")
            .openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.setRequestProperty("Accept-Encoding", "identity")
        conn.connectTimeout = 10000
        conn.readTimeout = 25000
        conn.doOutput = true
        conn.outputStream.use { it.write(json.toByteArray()) }
        val code = conn.responseCode
        if (code !in 200..299) {
            val resp = conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
            throw ApiError(code, friendlyError(code, resp))
        }
        val sb = StringBuilder()
        val calls = ArrayList<Pair<String, JSONObject>>()
        try {
            conn.inputStream.bufferedReader().use { br ->
                while (true) {
                    val line = br.readLine() ?: break
                    if (!line.startsWith("data:")) continue
                    val data = line.substring(5).trim()
                    if (data.isEmpty() || data == "[DONE]") continue
                    try {
                        val parts = JSONObject(data).optJSONArray("candidates")?.optJSONObject(0)
                            ?.optJSONObject("content")?.optJSONArray("parts") ?: continue
                        for (i in 0 until parts.length()) {
                            val p = parts.getJSONObject(i)
                            if (p.has("functionCall")) {
                                val fc = p.getJSONObject("functionCall")
                                calls.add(fc.getString("name") to (fc.optJSONObject("args") ?: JSONObject()))
                            } else if (!p.optBoolean("thought", false)) {
                                val tx = p.optString("text")
                                if (tx.isNotEmpty()) {
                                    sb.append(tx)
                                    onText(tx)
                                }
                            }
                        }
                    } catch (e: org.json.JSONException) {
                    }
                }
            }
        } catch (e: java.io.IOException) {
            if (sb.isEmpty() && calls.isEmpty()) throw e
        }
        return Reply(sb.toString(), calls)
    }

    private fun streamOnce(key: String, model: String, json: String, onText: (String) -> Unit): Reply {
        try {
            return streamRaw(key, model, json, onText)
        } catch (e: ApiError) {
            if (e.code == 400 && json.contains("thinkingConfig")) {
                return streamRaw(key, model, stripThinking(json), onText)
            }
            throw e
        }
    }

    private fun streamChain(key: String, json: String, onText: (String) -> Unit): Reply {
        var last: Exception = Exception("Không có model nào để thử")
        for (round in 0..1) {
            for (m in modelChain()) {
                try {
                    val out = streamOnce(key, m, json, onText)
                    okModel = m
                    return out
                } catch (e: ApiError) {
                    last = e
                    if (e.code == 400 || e.code == 401 || e.code == 403) throw e
                } catch (e: java.io.IOException) {
                    last = Exception("Mạng chậm hoặc mất kết nối (hết thời gian chờ). Kiểm tra Wi-Fi/4G rồi thử lại.")
                }
            }
            if (round == 0) Thread.sleep(1500)
        }
        throw last
    }

    private fun callGeminiStream(key: String, onText: (String) -> Unit): Reply =
        streamChain(key, buildBody(), onText)

    private fun postChain(key: String, json: String): String {
        var last: Exception = Exception("Không có model nào để thử")
        for (round in 0..1) {
            for (m in modelChain()) {
                try {
                    val out = postOnce(key, m, json)
                    okModel = m
                    return out
                } catch (e: ApiError) {
                    last = e
                    if (e.code == 400 || e.code == 401 || e.code == 403) throw e
                } catch (e: java.io.IOException) {
                    last = Exception("Mạng chậm hoặc mất kết nối (hết thời gian chờ). Kiểm tra Wi-Fi/4G rồi thử lại.")
                }
            }
            if (round == 0) Thread.sleep(1500)
        }
        throw last
    }

    private fun friendlyError(code: Int, resp: String): String {
        val msg = try {
            JSONObject(resp).optJSONObject("error")?.optString("message") ?: resp
        } catch (e: Exception) {
            resp
        }
        val hint = when (code) {
            503, 500 -> "Các model Gemini đang quá tải, đã thử nhiều model. Chờ một lát rồi gửi lại."
            429 -> "Hết lượt miễn phí tạm thời. Chờ vài phút rồi thử lại."
            404 -> "Model này không còn dùng được. Vào Cài đặt đổi tên model."
            400, 401, 403 -> "API key sai hoặc không có quyền. Kiểm tra lại key trong Cài đặt."
            else -> "Lỗi máy chủ."
        }
        return "$hint (HTTP $code)\n" + msg.take(150)
    }

    private fun buildBody(): String {
        val now = SimpleDateFormat("EEEE, dd/MM/yyyy HH:mm", Locale("vi", "VN")).format(Date())
        val sys = systemPrompt + " Thời gian hiện tại của người dùng: $now. " +
            "Bạn đang chạy trong ứng dụng Android và có các hàm điều khiển điện thoại. " +
            "CHỈ gọi hàm khi người dùng ra lệnh rõ ràng làm một hành động (mở app, gọi điện, nhắn tin, tìm kiếm, chỉ đường, hẹn giờ, vuốt/cuộn/quay lại/khóa máy). " +
            "Với trò chuyện thường, hỏi đáp, hỏi giờ, hỏi ngày, tâm sự: hãy trả lời trực tiếp bằng chữ ngay, không nói \"để mình xem\" hay \"để mình tìm\" và không gọi hàm. " +
            "Luôn trả lời bằng tiếng Việt." +
            " Khi cần thao tác điện thoại bạn PHẢI gọi hàm, tuyệt đối không trả lời bằng chữ kiểu \"Đã thực hiện\". " +
            "Muốn tìm kiếm bên trong app đang mở (Zalo, Facebook...) hãy dùng search_in_app; chỉ gọi search_web khi câu người dùng có từ \"tìm\" hoặc \"tìm kiếm\" (mở trình duyệt); mọi câu hỏi kiến thức, thời tiết, tin tức, \"là gì\", \"ở đâu\"... KHÔNG có từ \"tìm\" thì trả lời trực tiếp bằng chữ, tuyệt đối không mở trình duyệt. Chỉ dùng search_youtube khi người dùng nói rõ \"YouTube\". " +
            "\"Mở danh bạ\" gọi open_contacts. \"Gọi cho <tên>\" thường gọi call_phone; chỉ khi người dùng nói rõ gọi qua Zalo (ví dụ \"gọi Zalo cho <tên>\", \"mở Zalo gọi <tên>\") thì gọi call_zalo. " +
            "Lời nói đến từ nhận diện giọng nên có thể sai từ: nếu câu nghe vô nghĩa mà gần âm với một lệnh điều khiển (ví dụ \"muộn màng\" gần với \"cuộn màn hình\"), hãy hiểu là lệnh đó. " +
            "Nếu cần biết trên màn hình có gì thì gọi read_screen. " +
            "Khi người dùng muốn nhắn tin qua Zalo hoặc Messenger/Facebook hãy dùng send_message_in_app, message là đúng nội dung người dùng đọc. " +
            "Nếu ngữ cảnh cho biết đang ở khung chat thì các câu bắt đầu bằng \"soạn/nhập/viết/gõ tin (nhắn)\" luôn nghĩa là điền nội dung phía sau vào ô nhập hiện tại bằng compose_message; nội dung có thể chứa tên người hay địa điểm (ví dụ \"cửa hai\"), đừng hiểu đó là người nhận. " +
            "Chỉ dùng send_message_in_app khi người dùng nói rõ \"nhắn/gửi (Zalo, Messenger) cho <tên>\" và không phải đang ở đúng khung chat đó. " +
            "Khi người dùng nói nhận, từ chối hoặc kết thúc (cúp) cuộc gọi hãy gọi call_control. " +
            "Chỉ đường, dẫn đường, đi đến một nơi thì gọi navigate với tên địa điểm; \"dừng chỉ đường\" gọi stop_navigation; \"bật chế độ lái xe\" gọi drive_mode. " +
            "Đặt báo thức luôn dùng set_alarm (app Đồng hồ của máy): time dạng 24 giờ HH:MM (chiều/tối thì cộng 12 giờ), label là tên hoặc lý do người dùng nói (ví dụ \"đặt báo thức 6 giờ sáng thi kiểm tra\" -> time 06:00, label \"Thi kiểm tra\"); " +
            "nếu người dùng không nói tên thì đặt luôn, chỉ hỏi lại khi thiếu giờ. Tắt báo thức dùng alarm_off, bật lại dùng alarm_on, mở danh sách dùng show_alarms, hẹn giờ đếm ngược dùng set_timer. " +
            "Khi người dùng đang ở khung chat và nói \"nhập/soạn/viết tin nhắn ...\" hãy gọi compose_message với message là phần nội dung phía sau (giữ đúng lời người dùng, viết hoa chữ đầu, thêm dấu câu hợp lý, không thêm bớt ý). Nếu người dùng đọc nội dung khác ngay sau đó thì gọi lại compose_message với nội dung mới. " +
            "Để bình luận một bài viết hãy gọi lần lượt click_text \"Bình luận\", type_text nội dung, rồi click_text \"Gửi\" hoặc \"Đăng\". " +
            (if (voiceOn) " Đang trò chuyện bằng giọng nói: trả lời tối đa 2 câu ngắn, tự nhiên như bạn bè, không dùng ký hiệu, markdown hay emoji." else "") +
            (if (screenCtx.isNotBlank()) " " + screenCtx else "")
        val body = JSONObject()
        body.put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
        body.put("tools", JSONArray().put(JSONObject().put("functionDeclarations", toolDecls())))
        val contents = JSONArray()
        var hs = maxOf(0, history.size - 16)
        while (hs < history.size && history[hs].first != "user") hs++
        for (idx in hs until history.size) {
            val (r, t) = history[idx]
            contents.put(
                JSONObject().put("role", r)
                    .put("parts", JSONArray().put(JSONObject().put("text", t)))
            )
        }
        body.put("contents", contents)
        body.put("generationConfig", JSONObject().put("thinkingConfig", JSONObject().put("thinkingLevel", "minimal")))
        return body.toString()
    }

    private fun callGemini(key: String, model: String): Reply {
        val resp = postChain(key, buildBody())
        val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        val calls = ArrayList<Pair<String, JSONObject>>()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (p.has("functionCall")) {
                val fc = p.getJSONObject("functionCall")
                calls.add(fc.getString("name") to (fc.optJSONObject("args") ?: JSONObject()))
            } else {
                sb.append(p.optString("text"))
            }
        }
        return Reply(sb.toString(), calls)
    }

    // ---------------- TOOLS ----------------
    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "").replace('đ', 'd').trim()

    private fun runTool(name: String, a: JSONObject): String {
        return try {
            when (name) {
                "open_app" -> openApp(a.optString("app_name"))
                "call_phone" -> {
                    val who = a.optString("contact")
                    val n = resolveNumber(who)
                        ?: return "❌ Không tìm thấy số của \"$who\" (cần cấp quyền Danh bạ rồi nói lại)"
                    if (checkSelfPermission(android.Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                        startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$n")))
                        "📞 Đang gọi tới $who ($n)"
                    } else {
                        requestPermissions(arrayOf(android.Manifest.permission.CALL_PHONE), 7)
                        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n")))
                        "📞 Đã mở cuộc gọi tới $who ($n). Hãy cấp quyền Gọi điện để lần sau mình tự bấm gọi"
                    }
                }
                "send_sms" -> {
                    val who = a.optString("contact")
                    val n = resolveNumber(who)
                        ?: return "❌ Không tìm thấy số của \"$who\" (cần cấp quyền Danh bạ rồi nói lại)"
                    startActivity(
                        Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n"))
                            .putExtra("sms_body", a.optString("message"))
                    )
                    "💬 Đã soạn tin cho $who, bấm gửi để hoàn tất"
                }
                "open_contacts" -> openContacts()
                "call_zalo" -> {
                    val who = a.optString("contact").trim()
                    if (who.isBlank()) return "❌ Bạn muốn gọi Zalo cho ai?"
                    executeZaloCall(who)
                }
                "search_web" -> {
                    val lastUser = lastSpokenText
                    if (!Regex("\\btim\\b").containsMatchIn(norm(lastUser))) {
                        return "ℹ️ Mình chỉ mở trình duyệt khi bạn nói \"tìm\" hoặc \"tìm kiếm\". Bạn hỏi lại giúp mình nhé."
                    }
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.optString("query")))))
                    "🔎 Đã tìm: ${a.optString("query")}"
                }
                "search_youtube" -> {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(a.optString("query")))))
                    "▶️ Đã tìm trên YouTube: ${a.optString("query")}"
                }
                "navigate" -> {
                    val dest = a.optString("destination").trim()
                    if (dest.isEmpty()) return "❌ Bạn muốn đi đâu?"
                    startNavigation(dest)
                    "🧭 Đang tìm đường đến $dest..."
                }
                "stop_navigation" -> {
                    drive?.stopNavigation()
                    val svc = PhoneAgentService.instance
                    if (svc != null && svc.currentPackage() == "com.google.android.apps.maps") {
                        svc.clickText("Thoát")
                    } else {
                        "🛑 Đã dừng chỉ đường trong app. Nếu đang dùng Google Maps, hãy mở lên và bấm Thoát."
                    }
                }
                "drive_mode" -> {
                    if (floating) {
                        pendingDrive = true
                        openAppFromBubble()
                    } else {
                        enterDrive()
                    }
                    "🚗 Đang bật chế độ lái xe..."
                }
                "set_timer" -> {
                    val min = a.optString("minutes").toDoubleOrNull() ?: return "❌ Không hiểu số phút"
                    val msg = a.optString("message").ifBlank { "Hết giờ!" }
                    val secs = (min * 60).toInt().coerceIn(1, 86400)
                    try {
                        startActivity(
                            Intent(AlarmClock.ACTION_SET_TIMER)
                                .putExtra(AlarmClock.EXTRA_LENGTH, secs)
                                .putExtra(AlarmClock.EXTRA_MESSAGE, msg)
                                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                        )
                        "⏳ Đã hẹn giờ ${a.optString("minutes")} phút trong Đồng hồ"
                    } catch (e: Exception) {
                        setAlarmAt(System.currentTimeMillis() + (min * 60000).toLong(), msg, null)
                        "⏰ Đã hẹn sau ${a.optString("minutes")} phút"
                    }
                }
                "phone_control" -> {
                    var act = a.optString("action")
                    if (prefs.getBoolean("invert_scroll", false)) {
                        act = when (act) {
                            "scroll_up" -> "scroll_down"
                            "scroll_down" -> "scroll_up"
                            else -> act
                        }
                    }
                    val times = a.optString("times").toIntOrNull() ?: 1
                    agent { it.doActionRepeat(act, times) }
                }
                "set_alarm" -> setSystemAlarm(a.optString("time"), a.optString("label"), a.optString("days"))
                "show_alarms" -> {
                    startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS))
                    "⏰ Đã mở danh sách báo thức"
                }
                "alarm_off" -> alarmSwitch(a.optString("which"), false)
                "alarm_on" -> alarmSwitch(a.optString("which"), true)
                "call_control" -> {
                    val act = a.optString("action").ifBlank { "answer" }
                    val svc = PhoneAgentService.instance
                    val pkg = svc?.currentPackage() ?: ""
                    val cellular = pkg.contains("incall") || pkg.contains("dialer") || pkg.contains("telecom")
                    if (cellular && checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED) {
                        telecomCall(act)
                    } else {
                        val r = svc?.callControl(act) ?: ""
                        if (r.isNotEmpty()) r else telecomCall(act)
                    }
                }
                "compose_message" -> agent { svc ->
                    val msg = a.optString("message").trim()
                    if (msg.isBlank()) return@agent "❌ Chưa có nội dung tin nhắn"
                    svc.composeMessage(msg) { r ->
                        runOnUiThread {
                            addBubble(r, false)
                            if (r.startsWith("✍️")) {
                                if (prefs.getBoolean("confirm_send", true)) {
                                    pendingSendCurrent = true
                                    val q = "Mình đã điền tin: $msg. Bạn có muốn gửi không?"
                                    if (voiceOn) say(q) else addBubble("❓ $q Nói hoặc gõ \"gửi đi\" hoặc \"hủy\".", false)
                                } else {
                                    sendCurrentNow()
                                }
                            } else if (voiceOn) {
                                say(r)
                            }
                        }
                    }
                    "✍️ Đang điền tin nhắn..."
                }
                "send_message_in_app" -> {
                    val app = a.optString("app").ifBlank { "Zalo" }
                    val contact = a.optString("contact")
                    val msg = a.optString("message")
                    if (contact.isBlank() || msg.isBlank()) return "❌ Thiếu tên người nhận hoặc nội dung tin nhắn"
                    if (prefs.getBoolean("confirm_send", true)) {
                        pendingSend = Triple(app, contact, msg)
                        val q = "Gửi tin \"$msg\" cho $contact trong $app nhé? Nói \"gửi đi\" để xác nhận hoặc \"hủy\"."
                        if (voiceOn) say(q)
                        "❓ $q"
                    } else {
                        executeSend(app, contact, msg)
                    }
                }
                "click_text" -> agent { it.clickText(a.optString("text")) }
                "type_text" -> agent { it.typeText(a.optString("text")) }
                "read_screen" -> agent { it.readScreen() }
                "search_in_app" -> agent { svc ->
                    svc.searchInApp(a.optString("query")) { msg ->
                        runOnUiThread {
                            addBubble(msg, false)
                            if (voiceOn) setCaption(msg)
                        }
                    }
                    "🔎 Đang tìm \"" + a.optString("query") + "\" trong app..."
                }
                else -> "❌ Chưa hỗ trợ lệnh: $name"
            }
        } catch (e: Exception) {
            "❌ Lỗi: ${e.message}"
        }
    }

    private var pendingSend: Triple<String, String, String>? = null
    private var pendingSendCurrent = false
    private lateinit var tabBar: LinearLayout
    private var drive: DriveController? = null
    private var driveActive = false
    private var pendingNavDest: String? = null
    private var pendingDrive = false
    @Volatile private var screenCtx = ""

    // "soạn/nhập/viết/gõ tin (nhắn) ..." khi đang ở khung chat: điền thẳng vào ô nhập, không cần hỏi AI
    private fun quickCompose(text: String): String? {
        val m = Regex("^\\s*(soạn|nhập|viết|gõ)\\s+(tin nhắn|tin)\\s*[:,]?\\s*(.+)$", RegexOption.IGNORE_CASE).find(text) ?: return null
        val body = m.groupValues[3].trim()
        if (body.isEmpty() || body.lowercase().startsWith("cho ")) return null
        val svc = PhoneAgentService.instance ?: return null
        if (!svc.inChat()) return null
        val msg = body.replaceFirstChar { it.uppercase() }
        return runTool("compose_message", JSONObject().put("message", msg))
    }
    private var quietCount = 0

    private fun sendCurrentNow() {
        val svc = PhoneAgentService.instance
        if (svc == null) {
            addBubble("⚠️ Hãy bật Trợ năng \"Chim Cút Agent\" rồi thử lại", false)
            return
        }
        svc.sendCurrent { r ->
            runOnUiThread {
                addBubble(r, false)
                if (voiceOn) say(r)
            }
        }
    }

    private fun openContacts(): String {
        return try {
            startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CONTACTS))
            "📇 Đã mở Danh bạ"
        } catch (e: Exception) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI))
                "📇 Đã mở Danh bạ"
            } catch (e2: Exception) {
                "❌ Không mở được Danh bạ"
            }
        }
    }

    private fun executeZaloCall(contact: String): String {
        val num = try { resolveNumber(contact) } catch (e: Exception) { null }
        var viaLink = false
        if (num != null) {
            val digits = num.replace("+84", "0").filter { it.isDigit() }
            if (digits.length >= 9) {
                viaLink = try {
                    startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse("https://zalo.me/$digits")).setPackage("com.zing.zalo")
                    )
                    true
                } catch (e: Exception) {
                    false
                }
            }
        }
        if (!viaLink) {
            val opened = openApp("Zalo")
            if (opened.startsWith("❌")) return opened
        }
        ui.postDelayed({
            val svc = PhoneAgentService.instance
            if (svc == null) {
                addBubble("⚠️ Hãy bật Trợ năng \"Chim Cút Agent\" rồi thử lại", false)
                return@postDelayed
            }
            val report = { r: String ->
                runOnUiThread {
                    addBubble(r, false)
                    if (voiceOn) say(r)
                }
            }
            if (viaLink) {
                svc.pressCallInChat(contact) { r ->
                    if (r.startsWith("❌")) svc.callInApp(contact, report) else report(r)
                }
            } else {
                svc.callInApp(contact, report)
            }
        }, if (viaLink) 1500L else 3500L)
        return "📞 Đang gọi Zalo cho $contact..."
    }

    private val RXO = setOf(RegexOption.IGNORE_CASE)

    // Lệnh quen thuộc chạy ngay trên máy, không chờ Gemini (nhanh hơn rất nhiều)
    @Volatile private var lastSpokenText = ""

    private fun quickCommand(text: String): String? {
        lastSpokenText = text
        quickOpen(text)?.let { return it }
        val t = text.trim().trimEnd('.', ',', '!', '?', ' ')
        if (t.isEmpty() || t.length > 120) return null
        if (Regex("^(?:chim(?: cút)?(?: ơi)? )?mở khó[aá](?: màn hình| máy| điện thoại)?$", RXO).containsMatchIn(t)) {
            return runTool("phone_control", JSONObject().put("action", "unlock"))
        }
        Regex("^(?:gọi|alo)(?: điện| thoại)? (?:qua |bằng |trên )?zalo (?:cho |tới )?(.+)$", RXO).find(t)
            ?.let { return runTool("call_zalo", JSONObject().put("contact", it.groupValues[1])) }
        Regex("^(?:mở|bật) zalo (?:để |và |rồi )?(?:gọi|alo)(?: điện| thoại)? (?:cho |tới )?(.+)$", RXO).find(t)
            ?.let { return runTool("call_zalo", JSONObject().put("contact", it.groupValues[1])) }
        Regex("^(?:gọi|alo)(?: điện| thoại)? (?:cho )?(.+?) (?:qua|bằng|trên) zalo$", RXO).find(t)
            ?.let { return runTool("call_zalo", JSONObject().put("contact", it.groupValues[1])) }
        val low = t.lowercase(Locale.ROOT)
        if (!low.contains("zalo") && !low.contains("video")) {
            Regex("^(?:gọi|alo)(?: điện| thoại)? (?:cho |tới )?(.+)$", RXO).find(t)?.let {
                val who = it.groupValues[1]
                if (!who.startsWith("lại", true)) return runTool("call_phone", JSONObject().put("contact", who))
            }
        }
        Regex("^(?:chỉ đường|dẫn đường)(?: cho (?:mình|tôi|tớ))?(?: đến| tới| về)?\\s+(.+)$", RXO).find(t)
            ?.let { return runTool("navigate", JSONObject().put("destination", it.groupValues[1])) }
        Regex("^tìm(?: kiếm)?\\s+(.+)$", RXO).find(t)?.let {
            val pkg = PhoneAgentService.instance?.currentPackage() ?: ""
            val inChatApp = pkg.contains("zalo") || pkg.contains("facebook") || pkg.contains("orca")
            if (!inChatApp && !low.contains("youtube")) {
                return runTool("search_web", JSONObject().put("query", it.groupValues[1]))
            }
        }
        Regex("^(?:mở|bật)(?: ứng dụng| app)?\\s+(.+)$", RXO).find(t)?.let {
            val name = it.groupValues[1]
            if (name.split(" ").size <= 4) {
                val r = openApp(name)
                if (!r.startsWith("❌")) return r
            }
        }
        return null
    }

    // lệnh ngắn không cần hỏi AI: "mở danh bạ", "mở zalo"
    private fun quickOpen(text: String): String? {
        val t = norm(text)
        return when {
            Regex("^(chim cut )?(mo|bat) (ung dung |app )?danh ba$").containsMatchIn(t) -> openContacts()
            Regex("^(chim cut )?(mo|bat) (ung dung |app )?zalo$").containsMatchIn(t) -> openApp("Zalo")
            else -> null
        }
    }

    private fun executeSend(app: String, contact: String, msg: String): String {
        val target = if (norm(app).contains("zalo")) "Zalo" else "Messenger"
        var opened = openApp(target)
        if (opened.startsWith("❌") && target == "Messenger") opened = openApp("Facebook")
        if (opened.startsWith("❌")) return opened
        ui.postDelayed({
            val svc = PhoneAgentService.instance
            if (svc == null) {
                addBubble("⚠️ Hãy bật Trợ năng \"Chim Cút Agent\" rồi thử lại", false)
                return@postDelayed
            }
            svc.sendMessage(contact, msg) { r ->
                runOnUiThread {
                    addBubble(r, false)
                    if (voiceOn) say(r)
                }
            }
        }, 3500L)
        return "📨 Đang gửi tin cho $contact..."
    }

    private fun handlePendingSend(text: String): String? {
        if (pendingSendCurrent) {
            pendingSendCurrent = false
            val tc = norm(text)
            if (Regex("\\b(huy|thoi|khong|sai|dung gui)\\b").containsMatchIn(tc)) {
                return "Ok, mình không gửi. Tin vẫn nằm trong ô nhập."
            }
            if (Regex("\\b(gui|ok|oke|okay|dong y|xac nhan|chuan|dung roi|uh|u|ua|duoc|co)\\b").containsMatchIn(tc)) {
                sendCurrentNow()
                return "Ok, mình gửi nhé."
            }
            return null
        }
        val p = pendingSend ?: return null
        pendingSend = null
        val t = norm(text)
        if (Regex("\\b(huy|thoi|khong|sai|dung gui)\\b").containsMatchIn(t)) return "Đã hủy, mình không gửi."
        if (Regex("\\b(gui|ok|oke|okay|dong y|xac nhan|chuan|dung roi|uh|u|ua|duoc|co)\\b").containsMatchIn(t)) {
            return executeSend(p.first, p.second, p.third)
        }
        return null
    }

    private fun parseHm(s: String): Pair<Int, Int>? {
        val t = s.trim()
        val m = Regex("(\\d{1,2})\\s*(?:[:hHgG]|giờ)\\s*(\\d{1,2})?").find(t)
        val h: Int
        val min: Int
        if (m != null) {
            h = m.groupValues[1].toInt()
            min = m.groupValues[2].toIntOrNull() ?: 0
        } else {
            h = t.toIntOrNull() ?: return null
            min = 0
        }
        if (h !in 0..23 || min !in 0..59) return null
        return h to min
    }

    private fun parseDays(s: String): ArrayList<Int> {
        var t = norm(s)
        val out = ArrayList<Int>()
        if (t.isEmpty()) return out
        if (t.contains("hang ngay") || t.contains("moi ngay") || t.contains("daily") || t.contains("every")) {
            for (d in 1..7) out.add(d)
            return out
        }
        t = t.replace("thu hai", "t2").replace("thu ba", "t3").replace("thu tu", "t4")
            .replace("thu nam", "t5").replace("thu sau", "t6").replace("thu bay", "t7").replace("chu nhat", "cn")
        for (m in Regex("t[2-7]|cn").findAll(t)) {
            val d = if (m.value == "cn") 1 else m.value.substring(1).toInt()
            if (d !in out) out.add(d)
        }
        return out
    }

    private fun setSystemAlarm(timeStr: String, label: String, daysStr: String): String {
        val hm = parseHm(timeStr) ?: return "❌ Mình chưa hiểu giờ báo thức \"$timeStr\""
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hm.first)
            .putExtra(AlarmClock.EXTRA_MINUTES, hm.second)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val lb = label.trim()
        if (lb.isNotEmpty()) i.putExtra(AlarmClock.EXTRA_MESSAGE, lb)
        val days = parseDays(daysStr)
        if (days.isNotEmpty()) i.putIntegerArrayListExtra(AlarmClock.EXTRA_DAYS, days)
        return try {
            startActivity(i)
            val hhmm = String.format(Locale.US, "%02d:%02d", hm.first, hm.second)
            "⏰ Đã đặt báo thức $hhmm" + (if (lb.isNotEmpty()) " \"$lb\"" else "") +
                (if (days.size == 7) ", lặp hàng ngày" else if (days.isNotEmpty()) ", lặp lại theo thứ" else "") + " trong Đồng hồ"
        } catch (e: Exception) {
            "❌ Không đặt được báo thức trong app Đồng hồ: ${e.message}"
        }
    }

    // tắt/bật báo thức: báo thức đang kêu/sắp tới dùng lệnh hệ thống, còn lại bấm công tắc trong danh sách của app Đồng hồ
    private fun alarmSwitch(which: String, enable: Boolean): String {
        val t = norm(which)
        val ringing = !enable && (t.isEmpty() || t == "next" || t.contains("dang keu") || t.contains("tiep theo") || t.contains("sap toi"))
        if (ringing) {
            return try {
                startActivity(
                    Intent(AlarmClock.ACTION_DISMISS_ALARM)
                        .putExtra(AlarmClock.EXTRA_ALARM_SEARCH_MODE, AlarmClock.ALARM_SEARCH_MODE_NEXT)
                )
                "⏰ Đã gửi lệnh tắt báo thức đang kêu hoặc sắp tới"
            } catch (e: Exception) {
                "❌ Máy không hỗ trợ tắt báo thức bằng lệnh. Bạn nói \"tắt báo thức\" kèm giờ, ví dụ \"tắt báo thức 6 giờ\""
            }
        }
        if (enable && t.isEmpty()) return "❌ Bạn muốn bật báo thức giờ nào?"
        val svc = PhoneAgentService.instance
        if (svc == null) {
            if (enable && parseHm(which) != null) return setSystemAlarm(which, "", "")
            return "⚠️ Hãy bật Trợ năng \"Chim Cút Agent\" để chim bật/tắt báo thức trong Đồng hồ"
        }
        startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS))
        val verb = if (enable) "bật" else "tắt"
        ui.postDelayed({
            svc.toggleAlarms(which, enable) { r ->
                runOnUiThread {
                    addBubble(r, false)
                    if (voiceOn) say(r)
                }
            }
        }, 2200L)
        return "⏰ Đang mở Đồng hồ để $verb báo thức..."
    }

    private fun telecomCall(act: String): String {
        return try {
            if (checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) {
                return "❌ Không thấy nút trên màn hình, và app chưa có quyền nghe/tắt cuộc gọi (hãy cấp quyền Điện thoại)"
            }
            val tm = getSystemService(TELECOM_SERVICE) as android.telecom.TelecomManager
            when (act) {
                "answer" -> {
                    tm.acceptRingingCall()
                    "📞 Đã gửi lệnh nhận cuộc gọi (nếu máy đang đổ chuông)"
                }
                else -> {
                    if (Build.VERSION.SDK_INT >= 28 && tm.endCall()) {
                        if (act == "reject") "📵 Đã từ chối cuộc gọi" else "📵 Đã kết thúc cuộc gọi"
                    } else {
                        "❌ Không có cuộc gọi nào để xử lý"
                    }
                }
            }
        } catch (e: Exception) {
            "❌ Lỗi: ${e.message}"
        }
    }

    private fun quickCall(text: String): String? {
        val t = norm(text)
        val action = when {
            Regex("\\b(cup may|ngat may|ket thuc cuoc goi|tat cuoc goi|dung cuoc goi)\\b").containsMatchIn(t) -> "end"
            Regex("\\b(tu choi|khong nghe may)\\b").containsMatchIn(t) -> "reject"
            Regex("\\b(nhan|tra loi|bat) (cuoc goi|may|dien thoai)\\b|\\bnghe (may|dien thoai)\\b").containsMatchIn(t) -> "answer"
            else -> return null
        }
        return runTool("call_control", JSONObject().put("action", action))
    }

    private fun callStarts(calls: List<Pair<String, JSONObject>>): List<Long> {
        val out = ArrayList<Long>()
        var t = 0L
        for (c in calls) {
            out.add(t)
            t += if (c.first == "open_app") 3500L else 1800L
        }
        return out
    }

    private fun agent(block: (PhoneAgentService) -> String): String {
        val s = PhoneAgentService.instance
        if (s == null) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return "⚠️ Hãy bật \"Chim Cút Agent\" trong Trợ năng rồi thử lại"
        }
        return block(s)
    }

    private fun openApp(name: String): String {
        val pm = packageManager
        val q = norm(name)
        if (q.isBlank()) return "❌ Chưa biết mở app nào"
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { norm(it.loadLabel(pm).toString()) == q }
            ?: apps.firstOrNull { norm(it.loadLabel(pm).toString()).contains(q) }
            ?: apps.firstOrNull { val l = norm(it.loadLabel(pm).toString()); l.length >= 3 && q.contains(l) }
            ?: return "❌ Không tìm thấy app \"$name\""
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
            ?: return "❌ Không mở được app \"$name\""
        startActivity(i)
        return "📱 Đã mở ${hit.loadLabel(pm)}"
    }

    private fun resolveNumber(contact: String): String? {
        val t = contact.trim()
        if (Regex("^[0-9+ .\\-]{6,}$").matches(t)) return t.replace(Regex("[ .\\-]"), "")
        if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.READ_CONTACTS), 2)
            return null
        }
        val q = norm(t)
        val r = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
            null, null, null
        )?.use { cur ->
            var best: String? = null
            while (cur.moveToNext()) {
                val dn = norm(cur.getString(1) ?: "")
                if (dn == q) return@use cur.getString(0)
                if (best == null && dn.contains(q)) best = cur.getString(0)
            }
            best
        }
        return r?.replace(Regex("[ .\\-]"), "")
    }

    // ---------------- CHIM NỔI ----------------
    private var floating = false
    private var bubbleRoot: LinearLayout? = null
    private var bubbleQuail: QuailView? = null
    private var bubbleCaption: TextView? = null
    private var bubbleBig: LinearLayout? = null
    private var bubbleSmallView: TextView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var bubbleSmall = false
    private var lastTapAt = 0L
    private var pendingTap: Runnable? = null
    private var longPressRun: Runnable? = null

    private fun wm() = applicationContext.getSystemService(WINDOW_SERVICE) as WindowManager

    private fun setMode(m: QuailView.Mode) {
        quail.mode = m
        bubbleQuail?.mode = m
        drive?.quail?.mode = m
    }

    private fun setCaption(t: String) {
        captionTv.text = t
        drive?.caption?.text = t
        bubbleCaption?.let {
            it.text = t
            it.visibility = if (t.isBlank()) View.GONE else View.VISIBLE
        }
    }

    private fun goFloating() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Hãy bật \"Hiển thị trên các ứng dụng khác\" cho Chim Cút, rồi quay lại bấm lần nữa",
                Toast.LENGTH_LONG
            ).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (!voiceOn) {
            startConversation()
            if (!voiceOn) return
        }
        showBubble()
        ChimService.stopCallback = { runOnUiThread { stopFloating(true) } }
        startForegroundService(Intent(this, ChimService::class.java))
        floating = true
        moveTaskToBack(true)
    }

    private fun stopFloating(stopVoice: Boolean) {
        floating = false
        hideBubble()
        stopService(Intent(this, ChimService::class.java))
        if (stopVoice && voiceOn) stopConversation()
    }

    private fun hideBubble() {
        pendingTap?.let { ui.removeCallbacks(it) }
        longPressRun?.let { ui.removeCallbacks(it) }
        pendingTap = null
        longPressRun = null
        bubbleRoot?.let {
            try {
                wm().removeView(it)
            } catch (e: Exception) {
            }
        }
        bubbleRoot = null
        bubbleQuail = null
        bubbleCaption = null
        bubbleBig = null
        bubbleSmallView = null
        bubbleLp = null
        bubbleSmall = false
    }

    private fun applyBubbleState() {
        bubbleBig?.visibility = if (bubbleSmall) View.GONE else View.VISIBLE
        bubbleSmallView?.visibility = if (bubbleSmall) View.VISIBLE else View.GONE
        val lp = bubbleLp ?: return
        val root = bubbleRoot ?: return
        lp.flags = if (bubbleSmall) {
            lp.flags and WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON.inv()
        } else {
            lp.flags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        }
        try {
            wm().updateViewLayout(root, lp)
        } catch (e: Exception) {
        }
    }

    // chạm 1 lần khi chim to: dừng trò chuyện, thu nhỏ thành 🐥
    private fun shrinkBubble() {
        if (voiceOn) stopConversation()
        bubbleSmall = true
        applyBubbleState()
    }

    // chạm khi đang là 🐥: bật lại trò chuyện, chim to
    private fun expandBubble() {
        if (!voiceOn) startConversation()
        if (!voiceOn) return
        bubbleSmall = false
        applyBubbleState()
    }

    private fun openAppFromBubble() {
        applicationContext.startActivity(
            Intent(applicationContext, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        )
    }

    private fun handleBubbleTap() {
        if (bubbleSmall) {
            expandBubble()
            return
        }
        val now = SystemClock.uptimeMillis()
        if (now - lastTapAt < 330L) {
            pendingTap?.let { ui.removeCallbacks(it) }
            pendingTap = null
            lastTapAt = 0L
            openAppFromBubble()
        } else {
            lastTapAt = now
            val r = Runnable { shrinkBubble() }
            pendingTap = r
            ui.postDelayed(r, 340)
        }
    }

    private fun showBubble() {
        if (bubbleRoot != null) return
        bubbleSmall = false
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val q = QuailView(this)
        val faceBox = FrameLayout(this)
        faceBox.addView(q, FrameLayout.LayoutParams(dp(100), dp(104)))
        val close = TextView(this).apply {
            text = "✕"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(210, 74, 44, 18))
            }
            setOnClickListener { stopFloating(true) }
        }
        faceBox.addView(close, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.TOP or Gravity.END))
        val cap = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            maxLines = 3
            maxWidth = dp(220)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = GradientDrawable().apply {
                setColor(Color.argb(215, 40, 30, 60))
                cornerRadius = dp(12).toFloat()
            }
            visibility = View.GONE
        }
        val big = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        big.addView(faceBox)
        big.addView(cap, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(2) })
        val small = TextView(this).apply {
            text = "🐥"
            textSize = 28f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(235, 255, 233, 184))
                setStroke(dp(2), Color.argb(255, 217, 160, 102))
            }
            visibility = View.GONE
        }
        root.addView(big)
        root.addView(small, LinearLayout.LayoutParams(dp(58), dp(58)))
        q.mode = quail.mode

        val lp = WindowManager.LayoutParams(
            WRAP, WRAP,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(12)
        lp.y = dp(160)

        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        var longFired = false
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false; longFired = false
                    if (bubbleSmall) {
                        val r = Runnable {
                            longFired = true
                            stopFloating(true)
                        }
                        longPressRun = r
                        ui.postDelayed(r, 700)
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) {
                        moved = true
                        longPressRun?.let { ui.removeCallbacks(it) }
                    }
                    if (moved) {
                        lp.x = sx + dx.toInt()
                        lp.y = sy + dy.toInt()
                        wm().updateViewLayout(root, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    longPressRun?.let { ui.removeCallbacks(it) }
                    longPressRun = null
                    if (!moved && !longFired) handleBubbleTap()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    longPressRun?.let { ui.removeCallbacks(it) }
                    true
                }
                else -> false
            }
        }
        wm().addView(root, lp)
        bubbleRoot = root
        bubbleQuail = q
        bubbleCaption = cap
        bubbleBig = big
        bubbleSmallView = small
        bubbleLp = lp
    }

    // ---------------- CHẾ ĐỘ LÁI XE ----------------
    private fun setTalk(on: Boolean) {
        talkBtn.text = if (on) "⏹ Dừng trò chuyện" else "🎙 Bắt đầu trò chuyện"
        drive?.setTalkLabel(on)
    }

    private fun navSpeak(t: String) {
        val clean = cleanForSpeech(t)
        if (ttsReady && clean.isNotEmpty()) tts?.speak(clean, TextToSpeech.QUEUE_ADD, null, "nav")
    }

    private fun ensureDrive(): DriveController {
        drive?.let { return it }
        val d = DriveController(
            this, prefs,
            { t -> navSpeak(t) },
            { toggleConversation() },
            { exitDrive() },
            { msg ->
                addBubble(msg, false)
                drive?.caption?.text = msg
            }
        )
        drive = d
        return d
    }

    private fun enterDrive() {
        if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION), 6
            )
            return
        }
        val d = ensureDrive()
        driveActive = true
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        tabBar.visibility = View.GONE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        show(d.root)
        d.setTalkLabel(voiceOn)
        d.start()
    }

    private fun exitDrive() {
        driveActive = false
        drive?.stop()
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        tabBar.visibility = View.VISIBLE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        show(quailTab)
    }

    private fun startNavigation(dest: String) {
        pendingNavDest = dest
        if (openGoogleMaps(dest)) {
            pendingNavDest = null
            return
        }
        if (floating) {
            openAppFromBubble()
        } else {
            runPendingNav()
        }
    }

    // Chỉ đường bằng app Google Maps (mode=l: xe máy; đổi thành d nếu muốn ô tô)
    private val GMAPS_MODE = "l"

    private fun openGoogleMaps(dest: String): Boolean {
        return try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(dest) + "&mode=" + GMAPS_MODE))
                .setPackage("com.google.android.apps.maps")
            startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun runPendingNav() {
        val dest = pendingNavDest ?: return
        if (openGoogleMaps(dest)) {
            pendingNavDest = null
            addBubble("🧭 Đã mở Google Maps chỉ đường đến $dest", false)
            return
        }
        addBubble("⚠️ Không mở được Google Maps, dùng bản đồ trong app", false)
        if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION), 6
            )
            return
        }
        pendingNavDest = null
        if (!driveActive) enterDrive()
        drive?.navigateTo(dest)
    }

    // ---------------- QUAIL (trò chuyện bằng giọng nói) ----------------
    private lateinit var quailTab: LinearLayout
    private lateinit var quail: QuailView
    private lateinit var captionTv: TextView
    private lateinit var talkBtn: Button
    private var voiceOn = false
    private var recognizer: SpeechRecognizer? = null
    private var errCount = 0
    private val ui = Handler(Looper.getMainLooper())
    private val biasWords = arrayListOf(
        "cuộn màn hình", "cuộn xuống", "cuộn lên", "vuốt lên", "vuốt xuống", "quay lại", "về màn hình chính",
        "khóa màn hình", "mở Zalo", "mở Facebook", "mở YouTube", "tìm kiếm", "chụp màn hình", "Chim Cút"
    )
    private var ttsQueued = 0
    private var replyDone = false
    private var lastPartial = ""
    private var lastPartialAt = 0L
    private var stopSent = false
    private var stopAt = 0L
    private var handled = false
    private val silenceWatch = object : Runnable {
        override fun run() {
            if (!voiceOn) return
            val now = SystemClock.elapsedRealtime()
            if (lastPartial.isNotEmpty() && !handled) {
                if (!stopSent && now - lastPartialAt > 1200) {
                    stopSent = true
                    stopAt = now
                    setMode(QuailView.Mode.THINKING)
                    recognizer?.stopListening()
                } else if (stopSent && now - stopAt > 2500) {
                    handled = true
                    recognizer?.cancel()
                    errCount = 0
                    handleSpoken(lastPartial)
                    return
                }
            }
            ui.postDelayed(this, 200)
        }
    }

    private fun buildQuail() {
        quailTab = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#FFE9B8"), Color.parseColor("#FFB87A"))
            )
        }
        quail = QuailView(this)
        quailTab.addView(quail, LinearLayout.LayoutParams(MATCH, 0, 1f))
        captionTv = TextView(this).apply {
            textSize = 18f
            setTextColor(Color.parseColor("#4A2C12"))
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(4), dp(16), dp(8))
            minLines = 2
            maxLines = 5
            text = "Bấm nút bên dưới để trò chuyện với Chim Cút"
        }
        quailTab.addView(captionTv, LinearLayout.LayoutParams(MATCH, WRAP))
        talkBtn = btn("🎙 Bắt đầu trò chuyện") { toggleConversation() }.apply {
            textSize = 18f
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        quailTab.addView(
            talkBtn,
            LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(16), dp(4), dp(16), dp(4)) }
        )
        val floatBtn = btn("🐥 Thu nhỏ thành chim nổi") { goFloating() }.apply {
            textSize = 15f
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        quailTab.addView(
            floatBtn,
            LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(16), dp(2), dp(16), dp(2)) }
        )
        val driveBtn = btn("🚗 Chế độ lái xe") { enterDrive() }.apply {
            textSize = 15f
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        quailTab.addView(
            driveBtn,
            LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(16), dp(2), dp(16), dp(12)) }
        )
    }

    private fun toggleConversation() {
        if (voiceOn) stopConversation() else startConversation()
    }

    private fun startConversation() {
        val key = prefs.getString("key", "") ?: ""
        if (key.isBlank()) {
            Toast.makeText(this, "Hãy nhập API key trong Cài đặt", Toast.LENGTH_LONG).show()
            show(buildSettings())
            return
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            prefs.edit().putBoolean("asked_extra", true).apply()
            requestPermissions(
                arrayOf(
                    android.Manifest.permission.RECORD_AUDIO,
                    android.Manifest.permission.READ_CONTACTS,
                    android.Manifest.permission.ANSWER_PHONE_CALLS
                ), 3
            )
            return
        }
        if (!prefs.getBoolean("asked_extra", false) &&
            (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED)
        ) {
            prefs.edit().putBoolean("asked_extra", true).apply()
            requestPermissions(
                arrayOf(android.Manifest.permission.READ_CONTACTS, android.Manifest.permission.ANSWER_PHONE_CALLS), 5
            )
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Máy chưa có dịch vụ nhận diện giọng nói của Google", Toast.LENGTH_LONG).show()
            return
        }
        if (!ttsReady) {
            Toast.makeText(this, "Máy chưa có giọng đọc tiếng Việt, chim sẽ chỉ hiện chữ", Toast.LENGTH_LONG).show()
        }
        voiceOn = true
        errCount = 0
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setTalk(true)
        say("Dạ, mình nghe đây!")
    }

    private fun stopConversation() {
        voiceOn = false
        ttsQueued = 0
        replyDone = false
        ui.removeCallbacks(restoreBeepVols)
        restoreBeepStreams()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        ui.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        setMode(QuailView.Mode.IDLE)
        setTalk(false)
        setCaption("Đã dừng. Bấm nút để nói chuyện tiếp.")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 3 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startConversation()
        } else if (requestCode == 5) {
            startConversation()
        } else if (requestCode == 6 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (pendingNavDest != null) runPendingNav() else enterDrive()
        }
    }

    private fun cleanForSpeech(text: String): String =
        text.replace(Regex("[^\\p{L}\\p{N}\\s.,!?]"), "").trim()

    private fun speakChunk(text: String, flush: Boolean = false) {
        val clean = cleanForSpeech(text)
        if (clean.isEmpty()) return
        setMode(QuailView.Mode.SPEAKING)
        if (!ttsReady) return
        if (flush) ttsQueued = 0
        ttsQueued++
        tts?.speak(clean, if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "quail")
    }

    private fun onChunkDone() {
        if (ttsQueued > 0) ttsQueued--
        if (ttsQueued == 0 && replyDone) afterSpeak()
    }

    private fun playbackDone() {
        replyDone = true
        if (!ttsReady) {
            ui.postDelayed({ afterSpeak() }, 1500)
        } else if (ttsQueued == 0) {
            afterSpeak()
        }
    }

    private fun takeSentences(buf: StringBuilder): List<String> {
        val out = ArrayList<String>()
        while (true) {
            var cut = -1
            for (i in 0 until buf.length - 1) {
                val ch = buf[i]
                val nx = buf[i + 1]
                if ((ch == '.' || ch == '!' || ch == '?' || ch == '…') && nx.isWhitespace()) { cut = i; break }
                if (ch == '\n') { cut = i; break }
                if (ch == ',' && nx == ' ' && i >= 40) { cut = i; break }
            }
            if (cut < 0) break
            val sentence = buf.substring(0, cut + 1).trim()
            buf.delete(0, cut + 1)
            if (sentence.isNotEmpty()) out.add(sentence)
        }
        return out
    }

    private fun say(text: String) {
        setCaption(text)
        setMode(QuailView.Mode.SPEAKING)
        ttsQueued = 0
        replyDone = false
        speakChunk(text, true)
        playbackDone()
    }

    private fun afterSpeak() {
        if (!voiceOn) {
            setMode(QuailView.Mode.IDLE)
            return
        }
        ui.postDelayed({ listen() }, 250)
    }

    private var savedBeepVols: Map<Int, Int>? = null
    private val restoreBeepVols = Runnable { restoreBeepStreams() }

    private fun beepStreams(): IntArray {
        val list = ArrayList<Int>()
        list.add(AudioManager.STREAM_NOTIFICATION)
        list.add(AudioManager.STREAM_SYSTEM)
        list.add(AudioManager.STREAM_ALARM)
        list.add(AudioManager.STREAM_RING)
        if (Build.VERSION.SDK_INT >= 26) {
            list.add(AudioManager.STREAM_ACCESSIBILITY)
        }
        return list.toIntArray()
    }

    private fun muteBeepStreams(forceForVideo: Boolean = false) {
        val videoPlaying = forceForVideo || speakerPlaying()
        try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            val prev = savedBeepVols?.let { HashMap(it) } ?: HashMap<Int, Int>()
            for (st in beepStreams()) {
                val cur = am.getStreamVolume(st)
                if (!prev.containsKey(st)) {
                    prev[st] = cur
                }
                val target = if (videoPlaying) 0 else minOf(cur, 1)
                if (cur != target) {
                    am.setStreamVolume(st, target, 0)
                }
            }
            savedBeepVols = prev
            ui.removeCallbacks(restoreBeepVols)
            if (!videoPlaying) {
                ui.postDelayed(restoreBeepVols, 1200L)
            } else {
                ui.postDelayed({
                    if (!speakerPlaying()) restoreBeepStreams()
                }, 2500L)
            }
        } catch (e: Exception) {
        }
    }

    private fun restoreBeepStreams() {
        val prev = savedBeepVols ?: return
        savedBeepVols = null
        try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            for ((st, vol) in prev) {
                if (am.getStreamVolume(st) != vol) {
                    am.setStreamVolume(st, vol, 0)
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun listen() {
        if (!voiceOn) return
        setMode(QuailView.Mode.LISTENING)
        lastPartial = ""
        lastPartialAt = 0L
        stopSent = false
        handled = false
        ui.removeCallbacks(silenceWatch)
        ui.postDelayed(silenceWatch, 300)
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(applicationContext)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { setCaption("Đang nghe...") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) { quail.level = v; bubbleQuail?.level = v }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { setMode(QuailView.Mode.THINKING) }
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onPartialResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) {
                    setCaption("🎤 $t")
                    if (t != lastPartial) {
                        lastPartial = t
                        lastPartialAt = SystemClock.elapsedRealtime()
                    }
                }
            }
            override fun onError(e: Int) {
                if (handled) return
                ui.removeCallbacks(silenceWatch)
                if (lastPartial.isNotBlank() &&
                    e != SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS &&
                    e != SpeechRecognizer.ERROR_RECOGNIZER_BUSY
                ) {
                    handled = true
                    errCount = 0
                    handleSpoken(lastPartial)
                    return
                }
                onListenError(e)
            }
            override fun onResults(b: Bundle?) {
                if (handled) return
                ui.removeCallbacks(silenceWatch)
                val r0 = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                val text = if (r0.isNullOrBlank()) lastPartial else r0
                if (text.isBlank()) {
                    onListenError(SpeechRecognizer.ERROR_NO_MATCH)
                } else {
                    handled = true
                    errCount = 0
                    handleSpoken(text)
                }
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra("android.speech.extra.DICTATION_MODE", true)
            .putStringArrayListExtra("android.speech.extra.BIASING_STRINGS", biasWords)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 700L)
        val playing = speakerPlaying()
        if (playing) muteBeepStreams(true) else muteBeepStreams(false)
        r.startListening(i)
        if (!playing) {
            ui.postDelayed({ restoreBeepStreams() }, 900L)
        }
    }

    private fun onListenError(code: Int) {
        if (!voiceOn) return
        when (code) {
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                stopConversation()
                setCaption("Chưa cấp quyền micro cho app.")
            }
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                val playing = speakerPlaying()
                if (playing) {
                    quietCount = 0
                    muteBeepStreams(true)
                    setCaption("Đang nghe...")
                    ui.postDelayed({ listen() }, 1800L)
                } else {
                    if (!speakerPlaying()) restoreBeepStreams()
                    quietCount++
                    setCaption("Đang nghe...")
                    val delay = minOf(350L + quietCount * 350L, 2200L)
                    ui.postDelayed({ listen() }, delay)
                }
            }
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                ui.postDelayed({ listen() }, if (speakerPlaying()) 2200L else 1000L)
            else -> {
                errCount++
                if (errCount >= 5) {
                    stopConversation()
                    setCaption("Không nghe được (mã lỗi $code). Kiểm tra mạng và dịch vụ giọng nói của Google.")
                } else {
                    setCaption("Lỗi nghe (mã $code), đang thử lại...")
                    ui.postDelayed({ listen() }, if (speakerPlaying()) 2200L else 1200L)
                }
            }
        }
    }

    // Loa ngoài đang phát video/nhạc (không cắm tai nghe, không dùng Bluetooth)?
    private fun speakerPlaying(): Boolean {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        if (!am.isMusicActive) return false
        val onHeadset = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }
        return !onHeadset
    }

    // Khi loa ngoài đang phát video/nhạc, Chim chỉ nhận câu bắt đầu bằng "Chim" / "Chim ơi" / "Chim Cút ơi"
    // hoặc "mở khóa", "vuốt lên", "vuốt xuống", "quay lại". Các câu khác bị bỏ qua và nghe tiếp.
    private fun wakeFilter(raw: String): String? {
        val words = raw.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        fun w(i: Int): String = if (i < words.size) norm(words[i].trim(',', '.', '!', '?')) else ""
        val fillers = setOf("e", "nay", "ne", "hey", "alo", "ok", "oke")
        var i = 0
        while (i < 2 && w(i) in fillers) i++
        if (w(i) == "chim") {
            i++
            if (w(i) in setOf("cut", "cu", "cuc", "cud")) i++
            if (w(i) in setOf("oi", "a", "nhe")) i++
            return words.drop(i).joinToString(" ").trim(',', '.', '!', '?', ' ')
        }
        val two = w(i) + " " + w(i + 1)
        if (two == "mo khoa" || two == "vuot len" || two == "vuot xuong" || two == "quay lai") return raw
        return if (speakerPlaying()) null else raw
    }

    private fun handleSpoken(raw: String) {
        val wf = wakeFilter(raw)
        if (wf == null) {
            setMode(QuailView.Mode.LISTENING)
            setCaption("Đang nghe...")
            ui.postDelayed({ listen() }, if (speakerPlaying()) 2000L else 250L)
            return
        }
        if (wf.isEmpty()) {
            say("Dạ, mình nghe đây!")
            return
        }
        val text = wf
        quietCount = 0
        setMode(QuailView.Mode.THINKING)
        setCaption("Bạn: $text")
        addBubble(text, true)
        val pr = handlePendingSend(text)
        if (pr != null) {
            say(pr)
            return
        }
        val qk = quickCall(text) ?: quickCommand(text)
        if (qk != null) {
            addBubble(qk, false)
            say(qk)
            return
        }
        val qc = quickCompose(text)
        if (qc != null) {
            addBubble(qc, false)
            return
        }
        screenCtx = PhoneAgentService.instance?.screenContext() ?: ""
        lastSpokenText = text
        history.add("user" to text)
        ttsQueued = 0
        replyDone = false
        val key = prefs.getString("key", "") ?: ""
        Thread {
            var reply: Reply? = null
            var err = ""
            val pending = StringBuilder()
            val full = StringBuilder()
            try {
                reply = callGeminiStream(key) { chunk ->
                    full.append(chunk)
                    pending.append(chunk)
                    val sentences = takeSentences(pending)
                    val shown = full.toString().trim()
                    runOnUiThread {
                        if (voiceOn) {
                            setCaption(shown)
                            for (sn in sentences) speakChunk(sn)
                        }
                    }
                }
            } catch (e: Exception) {
                err = e.message ?: "lỗi không rõ"
            }
            val rest = pending.toString().trim()
            runOnUiThread {
                if (voiceOn && rest.isNotEmpty()) speakChunk(rest)
                finishVoiceReply(reply, err)
            }
        }.start()
    }

    private fun finishVoiceReply(reply: Reply?, err: String) {
        if (reply == null) {
            if (history.isNotEmpty()) history.removeAt(history.size - 1)
            if (!voiceOn) return
            addBubble("⚠️ $err", false)
            say("Mình đang bị chậm hoặc mất mạng, bạn nói lại nhé.")
            return
        }
        val calls = reply.calls
        val text = reply.text.trim()
        if (calls.isNotEmpty()) {
            if (history.isNotEmpty()) history.removeAt(history.size - 1)
        } else {
            history.add("model" to text.ifBlank { "(không có phản hồi)" })
        }
        if (text.isNotBlank()) addBubble(text, false)
        if (!voiceOn) return
        if (calls.isNotEmpty()) {
            val starts = callStarts(calls)
            calls.forEachIndexed { i, c ->
                ui.postDelayed({
                    val r = runTool(c.first, c.second)
                    addBubble(r, false)
                    if (text.isBlank()) setCaption(r)
                }, starts[i])
            }
            if (text.isNotBlank()) {
                playbackDone()
            } else {
                setMode(QuailView.Mode.SPEAKING)
                ui.postDelayed({ if (ttsQueued == 0) afterSpeak() }, starts.last() + 2500L)
            }
        } else if (text.isBlank()) {
            say("Mình chưa hiểu, bạn nói lại nhé.")
        } else {
            playbackDone()
        }
    }

    // ---------------- VOICE ----------------
    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN")
            .putStringArrayListExtra("android.speech.extra.BIASING_STRINGS", biasWords)
        try {
            startActivityForResult(i, REQ_VOICE)
        } catch (e: Exception) {
            Toast.makeText(this, "Máy không hỗ trợ nhận diện giọng nói", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VOICE && resultCode == RESULT_OK) {
            val t = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!t.isNullOrBlank()) send(t)
        }
    }

    // ---------------- ASSISTANTS ----------------
    private fun buildAssistants(): View {
        val sv = ScrollView(this)
        val p = page()
        p.addView(label("Danh sách trợ lý"))
        p.addView(btn("🤖 Chim Cút (mặc định)") { pickAssistant("Chim Cút", DEFAULT_PROMPT) })
        for ((name, prompt, _) in assistants) {
            p.addView(btn(name) { pickAssistant(name, prompt) })
        }
        sv.addView(p)
        return sv
    }

    private fun pickAssistant(name: String, prompt: String) {
        systemPrompt = prompt
        history.clear()
        chatList.removeAllViews()
        addBubble("Đã chuyển sang trợ lý: $name. Bạn muốn hỏi gì?", false)
        show(chatView)
    }

    // ---------------- RADIO ----------------
    private fun buildRadio(): View {
        val sv = ScrollView(this)
        val p = page()
        val status = TextView(this).apply { setTextColor(Color.LTGRAY); text = "Chọn một đài" }
        p.addView(label("Đài Radio Việt Nam"))
        p.addView(status)
        for ((name, url) in stations) p.addView(btn(name) { play(url, status) })
        val custom = edit("Dán link stream (mp3/aac) khác")
        p.addView(custom)
        p.addView(btn("Phát link này") {
            val u = custom.text.toString().trim()
            if (u.isNotEmpty()) play(u, status)
        })
        p.addView(btn("⏹ Dừng") {
            player?.release()
            player = null
            status.text = "Đã dừng"
        })
        sv.addView(p)
        return sv
    }

    private fun play(url: String, status: TextView) {
        player?.release()
        status.text = "Đang tải..."
        player = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA).build()
            )
            setOnPreparedListener { it.start(); status.text = "Đang phát: $url" }
            setOnErrorListener { _, _, _ -> status.text = "Không phát được (link hỏng?)"; true }
            try {
                setDataSource(url)
                prepareAsync()
            } catch (e: Exception) {
                status.text = "Lỗi: ${e.message}"
            }
        }
    }

    // ---------------- REMINDER ----------------
    private fun buildReminder(): View {
        val sv = ScrollView(this)
        val p = page()
        val msg = edit("Nội dung nhắc (vd: Uống thuốc)")
        val minutes = edit("Số phút (hẹn giờ)").apply { inputType = InputType.TYPE_CLASS_NUMBER }
        val list = TextView(this).apply { setTextColor(Color.LTGRAY); setPadding(0, dp(12), 0, 0) }
        p.addView(label("Lịch nhắc & Hẹn giờ"))
        p.addView(msg)
        p.addView(btn("Nhắc vào giờ cụ thể") {
            val c = Calendar.getInstance()
            TimePickerDialog(this, { _, h, m ->
                val t = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m); set(Calendar.SECOND, 0)
                    if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_MONTH, 1)
                }
                setAlarmAt(t.timeInMillis, msg.text.toString().ifBlank { "Đến giờ rồi!" }, list)
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
        })
        p.addView(minutes)
        p.addView(btn("Hẹn giờ sau N phút") {
            val n = minutes.text.toString().toLongOrNull()
            if (n == null || n <= 0) {
                Toast.makeText(this, "Nhập số phút", Toast.LENGTH_SHORT).show()
            } else {
                setAlarmAt(
                    System.currentTimeMillis() + n * 60000,
                    msg.text.toString().ifBlank { "Hết giờ!" }, list
                )
            }
        })
        p.addView(list)
        sv.addView(p)
        return sv
    }

    private fun setAlarmAt(ms: Long, msg: String, list: TextView?) {
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            this, alarmId++,
            Intent(this, AlarmReceiver::class.java).putExtra("msg", msg),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, pi)
        val t = SimpleDateFormat("HH:mm dd/MM", Locale.getDefault()).format(Date(ms))
        list?.append("⏰ $t - $msg\n")
        Toast.makeText(this, "Đã đặt nhắc lúc $t", Toast.LENGTH_SHORT).show()
    }

    // ---------------- VOICE SETTINGS ----------------
    private fun applyVoice() {
        try {
            tts?.setPitch(prefs.getFloat("pitch", 1f))
            tts?.setSpeechRate(prefs.getFloat("rate", 1f))
            val vn = prefs.getString("voice", "") ?: ""
            if (vn.isNotEmpty()) {
                val v = tts?.voices?.firstOrNull { it.name == vn }
                if (v != null) tts?.voice = v
            }
        } catch (e: Exception) {
        }
    }

    private fun speakTest() {
        tts?.speak("Xin chào, mình là Chim Cút. Rất vui được nói chuyện với bạn!", TextToSpeech.QUEUE_FLUSH, null, "test")
    }

    private fun addVoiceSettings(p: LinearLayout) {
        p.addView(label("Giọng nói"))
        val t = tts
        val voices = if (ttsReady && t != null) {
            try {
                (t.voices ?: emptySet()).filter { it.locale.language == "vi" }.sortedBy { it.name }
            } catch (e: Exception) {
                emptyList()
            }
        } else emptyList()
        if (voices.isEmpty()) {
            p.addView(TextView(this).apply {
                text = "Máy chưa có giọng đọc tiếng Việt. Cài ở Cài đặt máy → Quản lý chung → Chuyển văn bản thành giọng nói."
                setTextColor(Color.LTGRAY)
            })
        } else {
            val names = voices.mapIndexed { i, v ->
                "Giọng ${i + 1}" + (if (v.isNetworkConnectionRequired) " (cần mạng)" else "") + " · " + v.name
            }
            val sp = Spinner(this)
            sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
            val cur = prefs.getString("voice", "") ?: ""
            val idx = voices.indexOfFirst { it.name == cur }
            if (idx >= 0) sp.setSelection(idx)
            var first = true
            sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    if (first) {
                        first = false
                        return
                    }
                    prefs.edit().putString("voice", voices[pos].name).apply()
                    applyVoice()
                    speakTest()
                }

                override fun onNothingSelected(a: AdapterView<*>?) {}
            }
            p.addView(sp)
        }

        val pitchTv = TextView(this).apply { setTextColor(Color.WHITE) }
        val rateTv = TextView(this).apply { setTextColor(Color.WHITE) }
        val pitchBar = SeekBar(this).apply {
            max = 150
            progress = ((prefs.getFloat("pitch", 1f) - 0.5f) * 100).toInt()
        }
        val rateBar = SeekBar(this).apply {
            max = 150
            progress = ((prefs.getFloat("rate", 1f) - 0.5f) * 100).toInt()
        }
        fun refresh() {
            pitchTv.text = "Cao độ giọng: " + String.format(Locale.US, "%.2f", 0.5f + pitchBar.progress / 100f)
            rateTv.text = "Tốc độ nói: " + String.format(Locale.US, "%.2f", 0.5f + rateBar.progress / 100f)
        }
        fun save() {
            prefs.edit()
                .putFloat("pitch", 0.5f + pitchBar.progress / 100f)
                .putFloat("rate", 0.5f + rateBar.progress / 100f)
                .apply()
            applyVoice()
        }
        val change = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, v: Int, fromUser: Boolean) { refresh() }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                save()
                speakTest()
            }
        }
        pitchBar.setOnSeekBarChangeListener(change)
        rateBar.setOnSeekBarChangeListener(change)
        refresh()

        p.addView(TextView(this).apply {
            text = "Điệu giọng có sẵn:"
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(8), 0, 0)
        })
        val presets = listOf(
            Triple("Bình thường", 1.0f, 1.0f),
            Triple("Nhí nhảnh", 1.5f, 1.1f),
            Triple("Trầm ấm", 0.75f, 0.95f),
            Triple("Nói nhanh", 1.0f, 1.4f),
            Triple("Chậm rãi", 1.0f, 0.8f),
            Triple("Robot", 0.6f, 1.2f)
        )
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((name, pi, ra) in presets) {
            row.addView(btn(name) {
                pitchBar.progress = ((pi - 0.5f) * 100).toInt()
                rateBar.progress = ((ra - 0.5f) * 100).toInt()
                refresh()
                save()
                speakTest()
            })
        }
        val hs = HorizontalScrollView(this)
        hs.addView(row)
        p.addView(hs)
        p.addView(pitchTv)
        p.addView(pitchBar)
        p.addView(rateTv)
        p.addView(rateBar)
        p.addView(btn("🔊 Nghe thử") { speakTest() })
    }

    // ---------------- SETTINGS ----------------
    private fun buildSettings(): View {
        val sv = ScrollView(this)
        val p = page()
        val key = edit("Gemini API key").apply { setText(prefs.getString("key", "")) }
        val model = edit("Tên model").apply { setText(currentModel()) }
        val speak = CheckBox(this).apply {
            text = "Đọc to câu trả lời"
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("tts", true)
        }
        p.addView(label("Cài đặt"))
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "?" }
        p.addView(TextView(this).apply { text = "Phiên bản $ver"; setTextColor(Color.LTGRAY) })
        p.addView(TextView(this).apply {
            text = "Lấy API key miễn phí tại aistudio.google.com/apikey"
            setTextColor(Color.LTGRAY)
        })
        p.addView(key)
        p.addView(model)
        p.addView(speak)
        val invert = CheckBox(this).apply {
            text = "Đảo chiều cuộn (nếu chim cuộn ngược ý bạn)"
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("invert_scroll", false)
        }
        p.addView(invert)
        val confirm = CheckBox(this).apply {
            text = "Hỏi xác nhận trước khi gửi tin nhắn"
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("confirm_send", true)
        }
        p.addView(confirm)
        addVoiceSettings(p)
        p.addView(TextView(this).apply {
            text = "Để AI vuốt/cuộn/bấm được: bật Trợ năng \"Chim Cút Agent\". Để gọi theo tên: cấp quyền Danh bạ khi được hỏi."
            setTextColor(Color.LTGRAY)
        })
        p.addView(btn("Mở cài đặt Trợ năng") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        p.addView(btn("Lưu") {
            prefs.edit()
                .putString("key", key.text.toString().trim())
                .putString("model", model.text.toString().trim().ifBlank { DEFAULT_MODEL }.also { okModel = null })
                .putBoolean("tts", speak.isChecked)
                .putBoolean("invert_scroll", invert.isChecked)
                .putBoolean("confirm_send", confirm.isChecked).apply()
            Toast.makeText(this, "Đã lưu", Toast.LENGTH_SHORT).show()
        })
        sv.addView(p)
        return sv
    }
}
